package com.simplecam;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.*;
import android.hardware.camera2.params.MeteringRectangle;
import android.media.*;
import android.media.MediaCodecInfo.CodecCapabilities;
import android.media.MediaCodecInfo.CodecProfileLevel;
import android.os.*;
import android.view.*;
import android.widget.*;

import android.content.ContentValues;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.audiofx.AutomaticGainControl;
import android.media.audiofx.NoiseSuppressor;
import android.media.audiofx.AcousticEchoCanceler;

import java.io.File;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.opencv.android.OpenCVLoader;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

/**
* SimpleCam — минималистичная камера для горизонтального экрана.
*
* Слева — вертикальный Gain-слайдер (полная высота).
* Справа — рычаг Zoom + появляющийся слайдер Manual Focus.
* Снизу — панель управления с круглой кнопкой REC.
*/
public class MainActivity extends Activity implements SurfaceHolder.Callback {
	
	// ─── Константы ────────────────────────────────────────────────────────────
	private static final int VIDEO_W = 1280;
	private static final int VIDEO_H = 720;
	private static final int VIDEO_BPS_DEFAULT = 6_000_000;
	private static final int VIDEO_FPS = 30;
	private static final int AUDIO_SR = 48000;
	private static final int REQ_PERMS = 1;
	private static final float MAX_ZOOM_SPEED = 0.08f;
	
	// ─── UI ───────────────────────────────────────────────────────────────────
	private SurfaceView mSv;
	private Spinner mSpinner;
	private VerticalSeekBar mSeekGain;
	private FocusDrumView mFocusDrum; // барабан ручного фокуса
	private TextView mTvGain, mTvStatus, mTvFocus;
	private Button mBtn, mSrcToggleBtn, mBtnPause;
	private volatile boolean mPaused = false;
	private long mPauseStartNano = 0L, mPauseEndNano = 0L;
	private GradientDrawable mBtnBgPause;
	private VuMeterView mVu;
	private OscilloscopeView mOscilloscope;
	private EnvelopeView mEnvelope;
	private SpectrumView mSpectrum;
	private ZoomLeverView mZoomLever;
	private LinearLayout mAudioSrcPanel;
	private CheckBox mCbSoftClip, mCbManualFocus, mCbFocusAssist;
	private CheckBox mCbAgc, mCbNs, mCbEch, mCbStereo, mCbOscToggle, mCbManFocus;
	private SeekBar mSeekFocus;
	private LinearLayout mEisMainRow;
	private boolean mAudioSrcExpanded = false;
	private View mFocusColumn; // контейнер слайдера фокуса
	
	// Focus Assist: сохранённый зум до ассиста и хэндлер восстановления
	private volatile float mSavedZoomBeforeAssist = 1f;
	private Handler mFocusAssistHandler;
	
	// REC-кнопки фоны
	private GradientDrawable mBtnBgIdle, mBtnBgRec;
	
	// ─── Camera2 ──────────────────────────────────────────────────────────────
	private CameraManager mCamMgr;
	private CameraDevice mCamDev;
	private CameraCaptureSession mCapSess;
	private HandlerThread mCamThread;
	private Handler mCamHandler;
	private boolean mSurfaceReady;
	private boolean mPermsOk;
	private int mSensorOrientation = 90;
	private Rect mSensorRect;
	private float mMaxZoom = 1f;
	private volatile float mZoomLevel = 1f;
	private volatile float mZoomLeverPos = 0f;
	
	// Фокус
	private volatile boolean mManualFocus = false;
	private volatile float mFocusValue  = 0f; // 0..1 текущее (0=∞, 1=macro)
	private volatile float mFocusTarget = 0f; // цель для плавного перехода
	private float mMinFocusDist = 0f; // минимальная дистанция (диоптрии)
	
	// ─── Запись ───────────────────────────────────────────────────────────────
	private volatile boolean mRecording;
	private volatile float mGain = 1f;
	private volatile boolean mSoftClip = false;
	private volatile int mAudChannels = 2;

	private MediaCodec mVidEnc, mAudEnc;
	private MediaMuxer mMuxer;
	private Surface mEncSurface;
	private AudioRecord mAudRec;
	private Thread mAudThread;

	private int mVidTrack = -1, mAudTrack = -1;
	private volatile boolean mMuxReady;
	private final Object mMuxLock = new Object();

	// ─── MediaStore ───────────────────────────────────────────────────────────
	private Uri mPendingUri;
	private ParcelFileDescriptor mPfd;

	// ─── Аудио-источники ──────────────────────────────────────────────────────
	private final List<AudioSrcItem> mSrcList = new ArrayList<>();

	// ─── Аудио-поток ─────────────────────────────────────────────────────────
	private volatile boolean mAudRunning;

	// ═══════════════════════════════════════════════════════════════════════════
	// Pre-buffer: кольцевые буферы закодированных фреймов.
	//
	// Ключевая идея БЕСШОВНОСТИ:
	//   mVidWriteMode / mAudWriteMode — атомарные флаги:
	//     0 = RING  (фреймы идут в кольцо)
	//     1 = FLUSH (дренажный поток сбрасывает кольцо в мюксер, потом LIVE)
	//     2 = LIVE  (фреймы идут прямо в мюксер)
	//   Переключение RING→FLUSH→LIVE делает тот же поток, что дренирует
	//   энкодер, — поэтому между последним фреймом кольца и первым живым
	//   фреймом нет ни одного пропущенного пакета.
	// ═══════════════════════════════════════════════════════════════════════════
	private static class EncodedFrame {
		final byte[] data; final long pts; final int flags;
		EncodedFrame(ByteBuffer src, MediaCodec.BufferInfo bi) {
			data = new byte[bi.size];
			src.position(bi.offset); src.get(data, 0, bi.size);
			pts = bi.presentationTimeUs; flags = bi.flags;
		}
		boolean isKey() { return (flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0; }
	}
	private final java.util.ArrayDeque<EncodedFrame> mVidRing = new java.util.ArrayDeque<>();
	private final java.util.ArrayDeque<EncodedFrame> mAudRing = new java.util.ArrayDeque<>();
	private final Object mVidRingLock = new Object();
	private final Object mAudRingLock = new Object();
	// 0=RING 1=FLUSH 2=LIVE
	private volatile int mVidWriteMode = 0;
	private volatile int mAudWriteMode = 0;
	private volatile long mMuxBasePts  = 0L;
	private volatile MediaFormat mVidOutFmt = null;
	private volatile MediaFormat mAudOutFmt = null;
	private volatile boolean mVidLoopRunning = false;

	// ─── EIS — трекинг + запись через ByteBuffer MediaCodec ──────────────────
	private static final int TRACK_WIDTH   = 640;
	private static final int SEARCH_RADIUS = 80;
	private static final int EDGE_MARGIN   = 10;

	// Debug-слайдеры (volatile — изменяются из UI-треда, читаются из EIS-треда)
	private volatile int   eisMaxShift   = 60;
	private volatile int   eisTmplSize   = 150;   // квадратный патч
	private volatile float eisZoom       = 1.5f;

	private volatile boolean mEisEnabled      = false;
	private volatile double  mEisDriftSpeed   = 0.03;
	private volatile boolean mEisManualReset  = false;

	// Tracking state
	private Mat     eisRefFrame    = null;
	private Mat     eisTemplate    = null;
	private double  eisVirtualX    = 0;
	private double  eisVirtualY    = 0;
	private int     eisLastMatchX  = 0;
	private int     eisLastMatchY  = 0;
	private double  eisLastDx      = 0; // последний хороший offset X
	private double  eisLastDy      = 0; // последний хороший offset Y
	private Integer eisGhostOffX   = null;
	private Integer eisGhostOffY   = null;
	private int     eisActualW     = 0;
	private int     eisActualH     = 0;
	private int     eisIdealX      = 0;
	private int     eisIdealY      = 0;

	// ImageReader 640×360 YUV для EIS-анализа
	private android.media.ImageReader mEisReader;
	private ExecutorService           mEisExecutor;

	// Display overlay
	private ImageView mEisView       = null;
	private Bitmap    mEisDisplayBmp = null;

	// EIS video encoder (Surface-based, COLOR_FormatSurface)
	private MediaCodec mEisVidEnc      = null;
	private android.view.Surface mEisInputSurface = null;
	private int        mEisVidTrack    = -1;
	private volatile MediaFormat mEisVidOutFmt = null;
	private volatile boolean mEisEncReady = false;

	// WAV parallel recording
	private volatile boolean mWriteWav      = false;
	private java.io.FileOutputStream mWavFos = null;
	private java.io.RandomAccessFile mWavRaf = null;
	private long mWavTotalPcmBytes           = 0;
	private Uri  mWavPendingUri              = null;
	private java.io.File mWavTempFile        = null;

	// ─── Настройки ───────────────────────────────────────────────────────────
	private volatile int  mVideoBps = VIDEO_BPS_DEFAULT;
	private volatile int  mPreBufSecs = 1;          // 1..5 секунд
	private volatile boolean mPreBufferEnabled = true;
	private volatile int  mEvComp = 0;
	private int mEvMin = -6, mEvMax = 6;
	private SeekBar mSeekEv;
	private TextView mTvEv;
	
	// ─── Zoom-цикл ────────────────────────────────────────────────────────────
	private final Runnable mZoomRunnable = new Runnable() {
		@Override
		public void run() {
			float lever = mZoomLeverPos;
			if (Math.abs(lever) > 0.02f) {
				float abs = Math.abs(lever);
				float speed = (float) ((Math.exp(abs * 3.0) - 1.0) / (Math.exp(3.0) - 1.0)) * MAX_ZOOM_SPEED
				* Math.signum(lever);
				mZoomLevel = Math.max(1f, Math.min(mMaxZoom, mZoomLevel + speed));
				buildAndSendRequest();
			}
			if (mCamHandler != null)
			mCamHandler.postDelayed(this, 33);
		}
	};
	
	// =========================================================================
	// Lifecycle
	// =========================================================================
	
	@Override
	protected void onCreate(Bundle saved) {
		super.onCreate(saved);
		getWindow()
		.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
		mFocusAssistHandler = new Handler(Looper.getMainLooper());
		boolean opencvOk = OpenCVLoader.initDebug();
		mEisExecutor = Executors.newSingleThreadExecutor();
		setContentView(buildLayout());
		// Показываем статус инициализации OpenCV — если false, EIS работать не будет
		if (!opencvOk) {
			status("OpenCV init FAILED — EIS недоступен");
		}
		mCamMgr = (CameraManager) getSystemService(CAMERA_SERVICE);
		showAirplaneModeReminder();
		checkPerms();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (mRecording)
		mRecording = false;
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mCamHandler != null)
		mCamHandler.removeCallbacks(mZoomRunnable);
		if (mEisExecutor != null) { mEisExecutor.shutdownNow(); mEisExecutor = null; }
		if (mEisReader   != null) { mEisReader.close(); mEisReader = null; }
		if (mEisInputSurface != null) { mEisInputSurface.release(); mEisInputSurface = null; }
		if (eisRefFrame  != null) { eisRefFrame.release();  eisRefFrame  = null; }
		if (eisTemplate  != null) { eisTemplate.release();  eisTemplate  = null; }
		mVidLoopRunning = false;
		stopAudio();
		finalizeMuxer();
		if (mVidEnc!=null){try{mVidEnc.stop();mVidEnc.release();}catch(Exception e){} mVidEnc=null;}
		if (mEncSurface!=null){try{mEncSurface.release();}catch(Exception e){} mEncSurface=null;}
		try {
			if (mCapSess != null)
			mCapSess.close();
			} catch (Exception ignored) {
		}
		try {
			if (mCamDev != null)
			mCamDev.close();
			} catch (Exception ignored) {
		}
		if (mCamThread != null)
		mCamThread.quitSafely();
	}
	
	// =========================================================================
	// Layout
	// =========================================================================
	
	private View buildLayout() {
		FrameLayout root = new FrameLayout(this);
		root.setBackgroundColor(Color.BLACK);
		
		// Превью — сохраняем пропорции 16:9, центрируем в root
		mSv = new SurfaceView(this) {
			@Override
			protected void onMeasure(int wMs, int hMs) {
				int w = MeasureSpec.getSize(wMs);
				int h = MeasureSpec.getSize(hMs);
				int targetH = w * 9 / 16;
				if (targetH > h) {
					int targetW = h * 16 / 9;
					super.onMeasure(
						MeasureSpec.makeMeasureSpec(targetW, MeasureSpec.EXACTLY),
						MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
				} else {
					super.onMeasure(
						MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
						MeasureSpec.makeMeasureSpec(targetH, MeasureSpec.EXACTLY));
				}
			}
		};
		mSv.getHolder().addCallback(this);
		FrameLayout.LayoutParams svLP = new FrameLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
		svLP.gravity = Gravity.CENTER;
		root.addView(mSv, svLP);

		// EIS-оверлей: между SurfaceView и контролами, не перехватывает touch
		mEisView = new ImageView(this);
		mEisView.setScaleType(ImageView.ScaleType.FIT_CENTER);
		mEisView.setClickable(false);
		mEisView.setFocusable(false);
		mEisView.setElevation(0f);
		mEisView.setVisibility(View.GONE);
		FrameLayout.LayoutParams eisViewLP = new FrameLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
		eisViewLP.gravity = Gravity.CENTER;
		root.addView(mEisView, eisViewLP);

		// ── Осциллограф — прозрачный оверлей, верхняя часть кадра ─────────
		mOscilloscope = new OscilloscopeView(this);
		FrameLayout.LayoutParams oscLP = new FrameLayout.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT, dp(130));
		oscLP.gravity = Gravity.TOP | Gravity.LEFT;
		oscLP.leftMargin = dp(50); // не перекрывать Gain-слайдер
		oscLP.rightMargin = dp(60);
		oscLP.topMargin = dp(6);
		root.addView(mOscilloscope, oscLP);
		mOscilloscope.setVisibility(View.GONE);

		// ── Огибающая (бегущий 10-секундный осциллограф) — тот же оверлей ──────
		mEnvelope = new EnvelopeView(this);
		FrameLayout.LayoutParams envLP = new FrameLayout.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT, dp(130));
		envLP.gravity = Gravity.TOP | Gravity.LEFT;
		envLP.leftMargin = dp(50);
		envLP.rightMargin = dp(60);
		envLP.topMargin = dp(6);
		root.addView(mEnvelope, envLP);
		
		mBtnBgIdle  = makeOval(0xFFDDCC00);
		mBtnBgRec   = makeOval(0xFFCC1100);
		mBtnBgPause = makeOval(0xFF1155CC);
		
		// Внешний вертикальный контейнер: рабочая зона + нижняя панель
		LinearLayout outer = new LinearLayout(this);
		outer.setOrientation(LinearLayout.VERTICAL);
		outer.setElevation(dp(1)); // выше mEisView (elevation=0)
		root.addView(outer, mp_mp());
		
		// ── Рабочая зона ──────────────────────────────────────────────────────
		FrameLayout content = new FrameLayout(this);
		outer.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
		
		// ── Gain-слайдер (слева, ПОЛНАЯ высота экрана включая нижнюю панель) ──
		// Диапазон: -20 dB .. +20 dB (800 шагов), 0 dB = прогресс 400 (середина)
		mSeekGain = new VerticalSeekBar(this);
		mSeekGain.setMax(800);
		mSeekGain.setProgress(400); // 0 dB = середина
		mSeekGain.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar s, int p, boolean u) {
				// p=0 → -20 dB, p=400 → 0 dB, p=800 → +20 dB
				float db = -20f + p * 40f / 800f;
				mGain = (float) Math.pow(10.0, db / 20.0);
				if (mTvGain != null)
				mTvGain.setText(String.format("%+.1f", db) + "dB");
			}
			
			public void onStartTrackingTouch(SeekBar s) {}
			public void onStopTrackingTouch(SeekBar s) {}
		});
		// Добавляем в root (полная высота экрана), а не в content
		FrameLayout.LayoutParams gainLP = new FrameLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT);
		gainLP.gravity = Gravity.LEFT;
		root.addView(mSeekGain, gainLP);
		
		TextView tvGainLbl = smallLabel("GAIN");
		FrameLayout.LayoutParams gainLblLP = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
		ViewGroup.LayoutParams.WRAP_CONTENT);
		gainLblLP.gravity = Gravity.LEFT | Gravity.TOP;
		gainLblLP.leftMargin = dp(6);
		gainLblLP.topMargin = dp(4);
		root.addView(tvGainLbl, gainLblLP);
		
		mTvGain = smallLabel("+0.0dB");
		FrameLayout.LayoutParams gainValLP = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
		ViewGroup.LayoutParams.WRAP_CONTENT);
		gainValLP.gravity = Gravity.LEFT | Gravity.BOTTOM;
		gainValLP.leftMargin = dp(3);
		// Отступ снизу = высота нижней панели (~165dp) + запас 4dp
		gainValLP.bottomMargin = dp(169);
		root.addView(mTvGain, gainValLP);
		
		// ── Вертикальный VU-метр (справа от Gain-слайдера, полная высота) ──────
		mVu = new VuMeterView(this);
		FrameLayout.LayoutParams vuVertLP = new FrameLayout.LayoutParams(dp(14), ViewGroup.LayoutParams.MATCH_PARENT);
		vuVertLP.gravity = Gravity.LEFT;
		vuVertLP.leftMargin = dp(44);
		root.addView(mVu, vuVertLP);

		// ── Правая колонка: Focus-слайдер + Zoom-рычаг ───────────────────────
		// Добавляем в root (полная высота экрана), а не в content —
		// иначе при открытии панели настроек content сжимается и рычаги «схлопываются»
		LinearLayout rightCol = new LinearLayout(this);
		rightCol.setOrientation(LinearLayout.HORIZONTAL);
		FrameLayout.LayoutParams rightColLP = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
		ViewGroup.LayoutParams.MATCH_PARENT);
		rightColLP.gravity = Gravity.RIGHT;
		root.addView(rightCol, rightColLP);
		
		// Слайдер фокуса (скрыт по умолчанию)
		mFocusColumn = buildFocusColumn();
		mFocusColumn.setVisibility(View.GONE);
		rightCol.addView(mFocusColumn, new LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT));
		
		// Рычаг Zoom
		mZoomLever = new ZoomLeverView(this);
		mZoomLever.setListener(pos -> mZoomLeverPos = pos);
		rightCol.addView(mZoomLever, new LinearLayout.LayoutParams(dp(54), ViewGroup.LayoutParams.MATCH_PARENT));
		
		// ── Нижняя панель ─────────────────────────────────────────────────────
		LinearLayout panel = new LinearLayout(this);
		panel.setOrientation(LinearLayout.VERTICAL);
		panel.setBackgroundColor(0x00000000);
		// Левый паддинг = gain(44) + VU(14) + зазор(4) = 62dp
		panel.setPadding(dp(62), dp(2), dp(8), dp(3));
		outer.addView(panel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
		ViewGroup.LayoutParams.WRAP_CONTENT));
		
		// Тоггл аудио-источника — шестерёнка СЛЕВА от статуса.
		// panel имеет paddingLeft=52dp (чтобы не заходить за слайдер Gain),
		// поэтому шестерёнка слева не перекрывается ни слайдером, ни рычагом зума справа.
		mSrcToggleBtn = new Button(this);
		mSrcToggleBtn.setText("⚙");
		mSrcToggleBtn.setAllCaps(false);
		mSrcToggleBtn.setTextSize(28);
		mSrcToggleBtn.setTextColor(0xFFBBBBBB);
		mSrcToggleBtn.setBackground(null);
		mSrcToggleBtn.setPadding(0, 0, dp(8), 0);
		mSrcToggleBtn.setOnClickListener(v -> {
			mAudioSrcExpanded = !mAudioSrcExpanded;
			mAudioSrcPanel.setVisibility(mAudioSrcExpanded ? View.VISIBLE : View.GONE);
			mSrcToggleBtn.setText(mAudioSrcExpanded ? "⚙ ▴" : "⚙");
			// Восстанавливаем барабан фокуса если мануальный режим включён
			if (mFocusColumn != null)
				mFocusColumn.setVisibility(mManualFocus ? View.VISIBLE : View.GONE);
		});
		
		mTvStatus = new TextView(this);
		mTvStatus.setTextColor(0xFFAAAAAA);
		mTvStatus.setTextSize(11);
		mTvStatus.setText("Ready");
		mTvStatus.setSingleLine(false);
		mTvStatus.setMaxLines(2);
		mTvStatus.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
		// Шестерёнка слева, статус справа (weight=1)
		panel.addView(hrow(mSrcToggleBtn, mTvStatus));
		
		// Схлопываемая панель: спиннер + soft clip + manual focus
		// Центрируем по экрану — слайдер Gain слева не перекрывает
		mAudioSrcPanel = new LinearLayout(this);
		mAudioSrcPanel.setOrientation(LinearLayout.HORIZONTAL);
		mAudioSrcPanel.setVisibility(View.GONE);
		mAudioSrcPanel.setPadding(dp(8), dp(4), dp(8), dp(4));

		// ══════════════ ЛЕВЫЙ СТОЛБЕЦ — АУДИО ══════════════
		LinearLayout colAudio = new LinearLayout(this);
		colAudio.setOrientation(LinearLayout.VERTICAL);
		colAudio.setLayoutParams(new LinearLayout.LayoutParams(0,
			ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

		// Источник звука
		mSpinner = new Spinner(this);
		ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
			new ArrayList<String>());
		ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		mSpinner.setAdapter(ad);
		mSpinner.setLayoutParams(new LinearLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
				/* selection stored in mSpinner widget */
			}
			@Override
			public void onNothingSelected(AdapterView<?> p) {}
		});
		LinearLayout srcRow = new LinearLayout(this);
		srcRow.setOrientation(LinearLayout.HORIZONTAL);
		srcRow.setGravity(Gravity.CENTER_VERTICAL);
		srcRow.addView(smallLabel("Src: "));
		srcRow.addView(mSpinner);
		colAudio.addView(srcRow);

		// AGC / NoiseSuppressor / Echo
		mCbAgc = new CheckBox(this);
		mCbAgc.setText("AGC");
		mCbAgc.setTextColor(0xCCCCCCCC); mCbAgc.setTextSize(12);
		mCbNs = new CheckBox(this);
		mCbNs.setText("NoiseSup");
		mCbNs.setTextColor(0xCCCCCCCC); mCbNs.setTextSize(12);
		mCbEch = new CheckBox(this);
		mCbEch.setText("Echo");
		mCbEch.setTextColor(0xCCCCCCCC); mCbEch.setTextSize(12);
		/* AGC disabled unconditionally in disableAudioEffects() */
		/* NS disabled unconditionally */
		/* Ech disabled unconditionally */
		LinearLayout cbRow = new LinearLayout(this);
		cbRow.setOrientation(LinearLayout.HORIZONTAL);
		cbRow.addView(mCbAgc); cbRow.addView(mCbNs); cbRow.addView(mCbEch);
		colAudio.addView(cbRow);

		// Каналы + SoftClip
		mCbStereo = new CheckBox(this);
		mCbStereo.setText("Stereo");
		mCbStereo.setTextColor(0xCCCCCCCC); mCbStereo.setTextSize(12);
		mCbStereo.setChecked(true);
		mCbStereo.setOnCheckedChangeListener((cb, on) -> mAudChannels = on ? 2 : 1);
		mCbSoftClip = new CheckBox(this);
		mCbSoftClip.setText("SoftClip");
		mCbSoftClip.setTextColor(0xCCCCCCCC); mCbSoftClip.setTextSize(12);
		mCbSoftClip.setOnCheckedChangeListener((cb, on) -> mSoftClip = on);
		LinearLayout cbRow2 = new LinearLayout(this);
		cbRow2.setOrientation(LinearLayout.HORIZONTAL);
		cbRow2.addView(mCbStereo); cbRow2.addView(mCbSoftClip);
		colAudio.addView(cbRow2);

		// Осциллограф / Огибающая / Спектр toggle
		mCbOscToggle = new CheckBox(this);
		mCbOscToggle.setText("Osc");
		mCbOscToggle.setTextColor(0xCCCCCCCC); mCbOscToggle.setTextSize(12);
		mCbOscToggle.setOnCheckedChangeListener((cb, on) -> {
			if (mOscilloscope != null) mOscilloscope.setVisibility(on ? View.VISIBLE : View.GONE);
			if (mEnvelope     != null) mEnvelope.setVisibility(on ? View.GONE : View.VISIBLE);
		});
		mCbFocusAssist = new CheckBox(this);
		mCbFocusAssist.setText("FocAst");
		mCbFocusAssist.setTextColor(0xCCCCCCCC); mCbFocusAssist.setTextSize(12);
		mCbFocusAssist.setChecked(true);
		/* mCbFocusAssist.isChecked() read directly in focus handler */
		LinearLayout cbRow3 = new LinearLayout(this);
		cbRow3.setOrientation(LinearLayout.HORIZONTAL);
		cbRow3.addView(mCbOscToggle); cbRow3.addView(mCbFocusAssist);
		colAudio.addView(cbRow3);

		// Manual focus + Focus Assist — только чекбоксы.
		// Сам барабан фокуса (FocusDrumView) добавлен на основной экран в buildFocusColumn().
		mCbManFocus = new CheckBox(this);
		mCbManFocus.setText("Manual focus");
		mCbManFocus.setTextColor(0xCCCCCCCC); mCbManFocus.setTextSize(12);
		mCbManFocus.setOnCheckedChangeListener((cb, checked) -> {
			mManualFocus = checked;
			// post() чтобы сработало ПОСЛЕ того как панель настроек схлопнется
			final View fc = mFocusColumn;
			if (fc != null) fc.post(() -> {
				fc.setVisibility(checked ? View.VISIBLE : View.GONE);
			});
			if (mCamHandler != null)
				mCamHandler.post(MainActivity.this::buildAndSendRequest);
		});
		LinearLayout manRow = new LinearLayout(this);
		manRow.setOrientation(LinearLayout.HORIZONTAL);
		manRow.setGravity(Gravity.CENTER_VERTICAL);
		manRow.addView(mCbManFocus);
		colAudio.addView(manRow);

		// EV
		mTvEv = smallLabel("EV  0");
		mSeekEv = new SeekBar(this);
		mSeekEv.setMax(mEvMax - mEvMin); mSeekEv.setProgress(-mEvMin);
		mSeekEv.setLayoutParams(new LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT));
		mSeekEv.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar s, int p, boolean u) {
				mEvComp = mEvMin + p; updateEvLabel(mEvComp);
				if (mCamHandler != null) mCamHandler.post(MainActivity.this::buildAndSendRequest);
			}
			public void onStartTrackingTouch(SeekBar s) {}
			public void onStopTrackingTouch(SeekBar s) {}
		});
		LinearLayout evRow = new LinearLayout(this);
		evRow.setOrientation(LinearLayout.HORIZONTAL); evRow.setGravity(Gravity.CENTER_VERTICAL);
		evRow.addView(mTvEv); evRow.addView(mSeekEv);
		colAudio.addView(evRow);

		// WAV
		CheckBox cbWav = new CheckBox(this);
		cbWav.setText("Write WAV");
		cbWav.setTextColor(0xCCCCCCCC); cbWav.setTextSize(12);
		cbWav.setOnCheckedChangeListener((cb, on) -> mWriteWav = on);
		colAudio.addView(cbWav);

		mAudioSrcPanel.addView(colAudio);

		// ══════════════ ПРАВЫЙ СТОЛБЕЦ — ВИДЕО + EIS ══════════════
		LinearLayout colVideo = new LinearLayout(this);
		colVideo.setOrientation(LinearLayout.VERTICAL);
		colVideo.setLayoutParams(new LinearLayout.LayoutParams(0,
			ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
		colVideo.setPadding(dp(8), 0, 0, 0);

		// Битрейт
		String[] bpsL={"500k","1M","2M","3M","4M","6M(def)","8M","12M","20M"};
		int[] bpsV={500_000,1_000_000,2_000_000,3_000_000,4_000_000,6_000_000,8_000_000,12_000_000,20_000_000};
		Spinner spBps = new Spinner(this);
		ArrayAdapter<String> bpsAd = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, bpsL);
		bpsAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spBps.setAdapter(bpsAd); spBps.setSelection(5);
		spBps.setLayoutParams(new LinearLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		spBps.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { mVideoBps = bpsV[pos]; }
			public void onNothingSelected(AdapterView<?> p) {}
		});
		LinearLayout bpsRow = new LinearLayout(this);
		bpsRow.setOrientation(LinearLayout.HORIZONTAL); bpsRow.setGravity(Gravity.CENTER_VERTICAL);
		bpsRow.addView(smallLabel("Bps: ")); bpsRow.addView(spBps);
		colVideo.addView(bpsRow);

		// Pre-buffer (становится неактивным при EIS)
		CheckBox cbPB = new CheckBox(this);
		cbPB.setText("Pre-buf");
		cbPB.setTextColor(0xCCCCCCCC); cbPB.setTextSize(12);
		cbPB.setChecked(true);
		cbPB.setOnCheckedChangeListener((cb, on) -> mPreBufferEnabled = on);
		final TextView tvPBLen = smallLabel("1 s");
		SeekBar sbPB = new SeekBar(this);
		sbPB.setMax(4); sbPB.setProgress(0);
		sbPB.setLayoutParams(new LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT));
		sbPB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar s, int p, boolean u) {
				mPreBufSecs = p + 1; tvPBLen.setText(mPreBufSecs + "s");
			}
			public void onStartTrackingTouch(SeekBar s) {}
			public void onStopTrackingTouch(SeekBar s) {}
		});
		LinearLayout pbRow = new LinearLayout(this);
		pbRow.setOrientation(LinearLayout.HORIZONTAL); pbRow.setGravity(Gravity.CENTER_VERTICAL);
		pbRow.addView(cbPB); pbRow.addView(sbPB); pbRow.addView(tvPBLen);
		colVideo.addView(pbRow);

		// EIS checkbox — в правом столбце, серый divider сверху
		View div = new View(this);
		div.setLayoutParams(new LinearLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT, 1));
		div.setBackgroundColor(0x44FFFFFF);
		colVideo.addView(div);

		// EIS checkbox + SD/HD spinner — в одной строке
		CheckBox cbEIS = new CheckBox(this);
		cbEIS.setText("EIS stab");
		cbEIS.setTextColor(0xFFFFFFFF); cbEIS.setTextSize(13);

		Spinner spEisRes = new Spinner(this);
		ArrayAdapter<String> eisResAd = new ArrayAdapter<>(this,
			android.R.layout.simple_spinner_item, new String[]{"SD", "HD"});
		eisResAd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spEisRes.setAdapter(eisResAd);
		spEisRes.setSelection(0); // SD по умолчанию
		spEisRes.setLayoutParams(new LinearLayout.LayoutParams(
			ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		spEisRes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
				mEisReaderW = (pos == 0) ? 640  : 1280;
				mEisReaderH = (pos == 0) ? 480  : 960;
				// Перезапускаем reader если EIS включён
				if (mEisEnabled && mCamHandler != null)
					mCamHandler.post(MainActivity.this::startPreview);
			}
			public void onNothingSelected(AdapterView<?> p) {}
		});

		LinearLayout eisCheckRow = new LinearLayout(this);
		eisCheckRow.setOrientation(LinearLayout.HORIZONTAL);
		eisCheckRow.setGravity(Gravity.CENTER_VERTICAL);
		eisCheckRow.addView(cbEIS);
		eisCheckRow.addView(spEisRes);
		colVideo.addView(eisCheckRow);
		cbEIS.setOnCheckedChangeListener((cb, on) -> {
			try {
				mEisEnabled = on;
				mEisView.setVisibility(on ? View.VISIBLE : View.GONE);
				// Показываем/скрываем динамические контролы на основном экране
				mEisMainRow.setVisibility(on ? View.VISIBLE : View.GONE);
				// Pre-buffer несовместим с EIS — деактивируем
				cbPB.setEnabled(!on);
				sbPB.setEnabled(!on);
				if (on) {
					mPreBufferEnabled = false;
					cbPB.setChecked(false);
					eisActualW = 0; eisRefFrame = null; eisTemplate = null;
					status("EIS: ожидаю кадр…");
				} else {
					// Восстанавливаем pre-buffer
					cbPB.setEnabled(true);
					sbPB.setEnabled(true);
					status("EIS выкл");
				}
			} catch (Throwable t) {
				status("EIS: " + t.getClass().getSimpleName() + ": " + t.getMessage());
			}
		});

		// EIS debug слайдеры
		final TextView tvPatch = smallLabel("Patch 150");
		SeekBar sbPatch = new SeekBar(this);
		sbPatch.setMax(260); sbPatch.setProgress(110);
		sbPatch.setLayoutParams(new LinearLayout.LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT));
		sbPatch.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar s, int p, boolean u) {
				eisTmplSize = 40 + p; tvPatch.setText("P" + eisTmplSize);
				eisRefFrame = null; eisTemplate = null; eisActualW = 0;
			}
			public void onStartTrackingTouch(SeekBar s) {}
			public void onStopTrackingTouch(SeekBar s) {}
		});
		LinearLayout patchRow = new LinearLayout(this);
		patchRow.setOrientation(LinearLayout.HORIZONTAL); patchRow.setGravity(Gravity.CENTER_VERTICAL);
		patchRow.addView(tvPatch); patchRow.addView(sbPatch);
		colVideo.addView(patchRow);

		final TextView tvShift = smallLabel("Sh 60");
		SeekBar sbShift = new SeekBar(this);
		sbShift.setMax(110); sbShift.setProgress(50);
		sbShift.setLayoutParams(new LinearLayout.LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT));
		sbShift.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar s, int p, boolean u) {
				eisMaxShift = 10 + p; tvShift.setText("Sh" + eisMaxShift);
			}
			public void onStartTrackingTouch(SeekBar s) {}
			public void onStopTrackingTouch(SeekBar s) {}
		});
		LinearLayout shiftRow = new LinearLayout(this);
		shiftRow.setOrientation(LinearLayout.HORIZONTAL); shiftRow.setGravity(Gravity.CENTER_VERTICAL);
		shiftRow.addView(tvShift); shiftRow.addView(sbShift);
		colVideo.addView(shiftRow);

		final TextView tvZoom = smallLabel("Crop 1.5x");
		SeekBar sbZoom = new SeekBar(this);
		sbZoom.setMax(190); sbZoom.setProgress(40);
		sbZoom.setLayoutParams(new LinearLayout.LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT));
		sbZoom.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar s, int p, boolean u) {
				eisZoom = 1.1f + p / 100f; tvZoom.setText(String.format("C%.1fx", eisZoom));
			}
			public void onStartTrackingTouch(SeekBar s) {}
			public void onStopTrackingTouch(SeekBar s) {}
		});
		LinearLayout zoomRow = new LinearLayout(this);
		zoomRow.setOrientation(LinearLayout.HORIZONTAL); zoomRow.setGravity(Gravity.CENTER_VERTICAL);
		zoomRow.addView(tvZoom); zoomRow.addView(sbZoom);
		colVideo.addView(zoomRow);

		mAudioSrcPanel.addView(colVideo);

		panel.addView(mAudioSrcPanel);

		// ═══════════════════════════════════════════════════════════════════
		// Динамические EIS-контролы на основном экране (показываются когда EIS вкл)
		// ═══════════════════════════════════════════════════════════════════
		mEisMainRow = new LinearLayout(this);
		mEisMainRow.setOrientation(LinearLayout.HORIZONTAL);
		mEisMainRow.setGravity(Gravity.CENTER_VERTICAL);
		mEisMainRow.setBackgroundColor(0x66000000);
		mEisMainRow.setPadding(dp(6), dp(3), dp(6), dp(3));
		mEisMainRow.setVisibility(View.GONE); // скрыт пока EIS выкл

		// Кнопка сброса — крупнее чем раньше
		Button btnEisReset = new Button(this);
		btnEisReset.setText("↺ Reset");
		btnEisReset.setTextColor(Color.WHITE);
		btnEisReset.setTextSize(14);
		btnEisReset.setBackground(makeOval(0xFF555555));
		btnEisReset.setPadding(dp(14), dp(4), dp(14), dp(4));
		btnEisReset.setOnClickListener(v -> mEisManualReset = true);

		// Слайдер дрейфа
		final TextView tvDrift = smallLabel("Drift 0.030");
		SeekBar sbDrift = new SeekBar(this);
		sbDrift.setMax(200); sbDrift.setProgress(30);
		sbDrift.setLayoutParams(new LinearLayout.LayoutParams(dp(130), ViewGroup.LayoutParams.WRAP_CONTENT));
		sbDrift.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onProgressChanged(SeekBar s, int p, boolean u) {
				mEisDriftSpeed = (p + 1) / 1000.0;
				tvDrift.setText(String.format("Drift %.3f", mEisDriftSpeed));
			}
			public void onStartTrackingTouch(SeekBar s) {}
			public void onStopTrackingTouch(SeekBar s) {}
		});

		mEisMainRow.addView(btnEisReset);
		mEisMainRow.addView(tvDrift);
		mEisMainRow.addView(sbDrift);

		LinearLayout.LayoutParams eisMainLP = new LinearLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		eisMainLP.rightMargin = dp(120);
		panel.addView(mEisMainRow, eisMainLP);

		// ── Строка: спектр-анализатор (слева, weight=1) + кнопка REC (справа) ──
		// REC справа, с отступом rightMargin=58dp чтобы не перекрыть рычаг зума (54dp)
		// Спектр — только анализатор, занимает всю ширину нижней панели
		mSpectrum = new SpectrumView(this);
		LinearLayout.LayoutParams specLP = new LinearLayout.LayoutParams(
			ViewGroup.LayoutParams.MATCH_PARENT, dp(72));
		specLP.rightMargin = dp(120); // не заходить под кнопки REC+PAUSE
		panel.addView(mSpectrum, specLP);

		// ── REC и PAUSE фиксированы в root (FrameLayout), не сдвигаются ──────
		// REC — большая круглая кнопка, прикреплена к правому нижнему углу
		int recSize = dp(68);
		int recRight = dp(62); // 54dp зум-рычаг + 8dp зазор
		int recBottom = dp(8);

		mBtn = new Button(this);
		mBtn.setText("REC");
		mBtn.setTextColor(Color.WHITE);
		mBtn.setTextSize(13);
		mBtn.setBackground(mBtnBgIdle);
		mBtn.setOnClickListener(v -> onRecordClick());
		FrameLayout.LayoutParams recLP = new FrameLayout.LayoutParams(recSize, recSize);
		recLP.gravity = Gravity.BOTTOM | Gravity.RIGHT;
		recLP.rightMargin = recRight;
		recLP.bottomMargin = recBottom;
		root.addView(mBtn, recLP);

		// PAUSE — маленькая кнопка над REC, видна только во время записи
		mBtnPause = new Button(this);
		mBtnPause.setText("⏸");
		mBtnPause.setTextColor(Color.WHITE);
		mBtnPause.setTextSize(16);
		mBtnPause.setBackground(mBtnBgPause);
		mBtnPause.setVisibility(View.GONE);
		mBtnPause.setOnClickListener(v -> onPauseClick());
		FrameLayout.LayoutParams pauseLP = new FrameLayout.LayoutParams(dp(44), dp(44));
		pauseLP.gravity = Gravity.BOTTOM | Gravity.RIGHT;
		pauseLP.rightMargin = recRight + (recSize - dp(44)) / 2; // центр над REC
		pauseLP.bottomMargin = recBottom + recSize + dp(6);
		root.addView(mBtnPause, pauseLP);

		return root;
	}
	
	/** Строит колонку с барабаном фокуса (как кольцо на настоящей камере) */
	/** Плавно двигает mFocusValue к mFocusTarget со скоростью mEisDriftSpeed. */
	private void startFocusDrift() {
		if (mCamHandler == null) return;
		mCamHandler.post(new Runnable() {
			@Override public void run() {
				if (!mManualFocus) return;
				float target = mFocusTarget;
				float cur    = mFocusValue;
				float diff   = target - cur;
				// Скорость дрейфа — тот же слайдер что у EIS (0.001..0.2)
				float speed  = (float) mEisDriftSpeed * 8f; // чуть быстрее чем видео-стаб
				if (Math.abs(diff) < 0.005f) {
					mFocusValue = target;
					if (mCamHandler != null) mCamHandler.post(MainActivity.this::buildAndSendRequest);
					return;
				}
				mFocusValue = cur + diff * Math.min(speed, 1f);
				if (mCamHandler != null) {
					mCamHandler.post(MainActivity.this::buildAndSendRequest);
					mCamHandler.postDelayed(this, 16); // ~60fps
				}
			}
		});
	}

	private View buildFocusColumn() {
		FrameLayout col = new FrameLayout(this);
		col.setBackgroundColor(0x33000000);
		
		mFocusDrum = new FocusDrumView(this);
		mFocusDrum.setOnFocusChangeListener(value -> {
			mFocusValue = value;
			mFocusTarget = value;
			updateFocusLabel(value);
			if (mManualFocus && mCamHandler != null)
				mCamHandler.post(MainActivity.this::buildAndSendRequest);
		});
		mFocusDrum.setOnDrumScrollListener(new FocusDrumView.OnDrumScrollListener() {
			@Override
			public void onScrollStart() {
				if (mCbFocusAssist == null || !mCbFocusAssist.isChecked()) return;
				// Отменяем отложенное восстановление (вдруг снова начали крутить)
				mFocusAssistHandler.removeCallbacksAndMessages(null);
				// Запоминаем текущий зум и форсируем максимальный (или ×3, но не меньше 4)
				mSavedZoomBeforeAssist = mZoomLevel;
				float assistZoom = Math.min(mMaxZoom, Math.max(mZoomLevel * 3f, 4f));
				mZoomLevel = assistZoom;
				if (mCamHandler != null) mCamHandler.post(MainActivity.this::buildAndSendRequest);
			}
			@Override
			public void onScrollStop() {
				if (mCbFocusAssist == null || !mCbFocusAssist.isChecked()) return;
				// Через 300 мс восстанавливаем зум
				mFocusAssistHandler.removeCallbacksAndMessages(null);
				mFocusAssistHandler.postDelayed(() -> {
					mZoomLevel = mSavedZoomBeforeAssist;
					if (mCamHandler != null) mCamHandler.post(MainActivity.this::buildAndSendRequest);
				}, 300);
			}
		});
		
		FrameLayout.LayoutParams drumLP = new FrameLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
		col.addView(mFocusDrum, drumLP);
		
		// Метки ∞ сверху, макро снизу
		TextView tvTop = smallLabel("∞");
		FrameLayout.LayoutParams topLP = new FrameLayout.LayoutParams(
		ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		topLP.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
		topLP.topMargin = dp(4);
		col.addView(tvTop, topLP);
		
		TextView tvBot = smallLabel("▲");
		FrameLayout.LayoutParams botLP = new FrameLayout.LayoutParams(
		ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		botLP.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
		botLP.bottomMargin = dp(4);
		col.addView(tvBot, botLP);
		
		mTvFocus = smallLabel("∞");
		FrameLayout.LayoutParams midLP = new FrameLayout.LayoutParams(
		ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		midLP.gravity = Gravity.CENTER;
		col.addView(mTvFocus, midLP);
		
		return col;
	}
	
	private void updateFocusLabel(float value) {
		if (mTvFocus == null) return;
		String txt = value < 0.005f ? "∞" : String.format("%.1f", value * mMinFocusDist) + "m⁻¹";
		mTvFocus.setText(txt);
	}

	private void updateEvLabel(int ev) {
		if (mTvEv == null) return;
		runOnUiThread(() -> mTvEv.setText(ev == 0 ? "EV  0" : String.format("EV %+d", ev)));
	}
	
	// ── Helpers ───────────────────────────────────────────────────────────────
	
	private GradientDrawable makeOval(int color) {
		GradientDrawable d = new GradientDrawable();
		d.setShape(GradientDrawable.OVAL);
		d.setColor(color);
		return d;
	}
	
	private TextView smallLabel(String t) {
		TextView v = new TextView(this);
		v.setText(t);
		v.setTextColor(0xCCCCCCCC);
		v.setTextSize(11);
		v.setBackgroundColor(0x88000000);
		v.setPadding(dp(3), dp(1), dp(3), dp(1));
		return v;
	}
	
	private LinearLayout hrow(View... views) {
		LinearLayout ll = new LinearLayout(this);
		ll.setOrientation(LinearLayout.HORIZONTAL);
		ll.setGravity(Gravity.CENTER_VERTICAL);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
		ViewGroup.LayoutParams.WRAP_CONTENT);
		lp.bottomMargin = dp(2);
		ll.setLayoutParams(lp);
		for (View v : views) {
			if (v.getLayoutParams() == null)
			v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
			ViewGroup.LayoutParams.WRAP_CONTENT));
			ll.addView(v);
		}
		return ll;
	}
	
	private ViewGroup.LayoutParams mp_mp() {
		return new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
	}
	
	private int dp(int x) {
		return Math.round(x * getResources().getDisplayMetrics().density);
	}
	
	// =========================================================================
	// Напоминание — авиарежим
	// =========================================================================

	private void showAirplaneModeReminder() {
		new android.app.AlertDialog.Builder(this)
			.setTitle("\u2708  Airplane Mode recommended")
			.setMessage(
				"For distraction-free recording:\n\n" +
				"  \u2022  Turn on Airplane Mode\n\n" +
				"This prevents calls, notifications\n" +
				"and Wi-Fi interruptions during recording.\n\n" +
				"(Screen will stay on while the app is open.)")
			.setPositiveButton("Got it", null)
			.setNeutralButton("Open Settings", (d, w) -> {
				try {
					startActivity(new android.content.Intent(
						android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS));
				} catch (Exception ignored) {}
			})
			.show();
	}

	// =========================================================================
	// Разрешения
	// =========================================================================
	
	private void checkPerms() {
		List<String> need = new ArrayList<>();
		if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
		need.add(Manifest.permission.CAMERA);
		if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
		need.add(Manifest.permission.RECORD_AUDIO);
		if (need.isEmpty()) {
			mPermsOk = true;
			if (mSurfaceReady)
			openCamera();
		} else
		requestPermissions(need.toArray(new String[0]), REQ_PERMS);
	}
	
	@Override
	public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
		for (int r : res) {
			if (r != PackageManager.PERMISSION_GRANTED) {
				status("Permissions required");
				return;
			}
		}
		mPermsOk = true;
		if (mSurfaceReady)
		openCamera();
	}
	
	// =========================================================================
	// SurfaceHolder.Callback
	// =========================================================================
	
	@Override
	public void surfaceCreated(SurfaceHolder h) {
		mSurfaceReady = true;
		if (mPermsOk)
		openCamera();
	}
	
	@Override
	public void surfaceChanged(SurfaceHolder h, int f, int w, int t) {
	}
	
	@Override
	public void surfaceDestroyed(SurfaceHolder h) {
		mSurfaceReady = false;
	}
	
	// =========================================================================
	// Camera2
	// =========================================================================
	
	@SuppressLint("MissingPermission")
	private void openCamera() {
		if (mCamThread == null || !mCamThread.isAlive()) {
			mCamThread = new HandlerThread("cam");
			mCamThread.start();
			mCamHandler = new Handler(mCamThread.getLooper());
		}
		try {
			String camId = null;
			for (String id : mCamMgr.getCameraIdList()) {
				CameraCharacteristics ch = mCamMgr.getCameraCharacteristics(id);
				Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
				if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
					camId = id;
					Integer so = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
					if (so != null)
					mSensorOrientation = so;
					Rect rect = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
					if (rect != null)
					mSensorRect = rect;
					Float maxZ = ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
					if (maxZ != null)
					mMaxZoom = maxZ;
					Float minFocus = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
					if (minFocus != null) mMinFocusDist = minFocus;
					android.util.Range<Integer> evR = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
					if (evR != null) { mEvMin = evR.getLower(); mEvMax = evR.getUpper(); }
					break;
				}
			}
			if (camId == null)
			camId = mCamMgr.getCameraIdList()[0];
			
			mCamMgr.openCamera(camId, new CameraDevice.StateCallback() {
				@Override
				public void onOpened(CameraDevice dev) {
					mCamDev = dev;
					startPreview();
					buildAudioSources();
					mCamHandler.post(mZoomRunnable);
					runOnUiThread(() -> { if (mSeekEv!=null){mSeekEv.setMax(mEvMax-mEvMin);mSeekEv.setProgress(-mEvMin);updateEvLabel(0);} });
				}
				
				@Override
				public void onDisconnected(CameraDevice dev) {
					dev.close();
					mCamDev = null;
				}
				
				@Override
				public void onError(CameraDevice dev, int e) {
					dev.close();
					mCamDev = null;
				}
			}, mCamHandler);
			} catch (Exception e) {
			status("openCamera: " + e.getMessage());
		}
	}
	
	private void startPreview() {
		if (mCamDev == null || !mSurfaceReady)
		return;
		ensureEncoders();
		// Пересоздаём EIS reader при каждом старте превью
		ensureEisReader();
		try {
			if (mCapSess != null) {
				mCapSess.close();
				mCapSess = null;
			}
			Surface preview = mSv.getHolder().getSurface();
			List<Surface> targets = new ArrayList<>();
			targets.add(preview);
			if (mEncSurface != null && mEncSurface.isValid())
			targets.add(mEncSurface);
			// EIS reader всегда в сессии — данные читаем только когда mEisEnabled
			if (mEisReader != null)
			targets.add(mEisReader.getSurface());
			
			mCamDev.createCaptureSession(targets, new CameraCaptureSession.StateCallback() {
				@Override
				public void onConfigured(CameraCaptureSession sess) {
					mCapSess = sess;
					buildAndSendRequest();
				}
				
				@Override
				public void onConfigureFailed(CameraCaptureSession sess) {
					status("Session config failed");
				}
			}, mCamHandler);
			} catch (Exception e) {
			status("startPreview: " + e.getMessage());
		}
	}
	
	private void buildAndSendRequest() {
		CameraCaptureSession sess = mCapSess;
		CameraDevice dev = mCamDev;
		if (sess == null || dev == null || !mSurfaceReady)
		return;
		try {
			// Всегда TEMPLATE_PREVIEW — шаблон не переключается при старте записи,
			// поэтому AE не пересчитывается и яркость не прыгает.
			// Encoder surface просто добавляется как дополнительный target.
			int tmpl = CameraDevice.TEMPLATE_PREVIEW;
			Surface preview = mSv.getHolder().getSurface();
			CaptureRequest.Builder rb = dev.createCaptureRequest(tmpl);
			rb.addTarget(preview);
			if (mEncSurface != null && mEncSurface.isValid())
			rb.addTarget(mEncSurface);
			if (mEisReader != null)
			rb.addTarget(mEisReader.getSurface());
			
			if (mManualFocus) {
				// Ручной фокус: переводим прогресс (0=∞, 1=macro) в диоптрии
				// Верх слайдера = прогресс 100 = macro (mMinFocusDist)
				// Низ слайдера  = прогресс 0   = бесконечность (0 диоптрий)
				float diopters = mFocusValue * mMinFocusDist;
				rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF);
				rb.set(CaptureRequest.LENS_FOCUS_DISTANCE, diopters);
				} else {
				rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
			}
			
			rb.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
			rb.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, mEvComp);
			
			if (mSensorRect != null) {
				int cropW = Math.max(1, (int) (mSensorRect.width() / mZoomLevel));
				int cropH = Math.max(1, (int) (mSensorRect.height() / mZoomLevel));
				int cropX = mSensorRect.left + (mSensorRect.width() - cropW) / 2;
				int cropY = mSensorRect.top + (mSensorRect.height() - cropH) / 2;
				rb.set(CaptureRequest.SCALER_CROP_REGION, new Rect(cropX, cropY, cropX + cropW, cropY + cropH));
			}
			sess.setRepeatingRequest(rb.build(), null, mCamHandler);
			} catch (Exception ignored) {
		}
	}
	
	// =========================================================================
	// EIS
	// =========================================================================

	/**
	 * ImageReader 640×360 YUV для трекинга.
	 * maxImages=4 чтобы executor успевал обрабатывать без "already acquired".
	 */
	private void ensureEisReader() {
		if (mEisReader != null) {
			try { mEisReader.close(); } catch (Exception ignored) {}
			mEisReader = null;
		}
		// mEisReaderW×mEisReaderH: SD=640×480, HD=1280×960 (выбирается в настройках)
			mEisReader = android.media.ImageReader.newInstance(
					mEisReaderW, mEisReaderH, android.graphics.ImageFormat.YUV_420_888, 4);
		mEisReader.setOnImageAvailableListener(reader -> {
			android.media.Image img = null;
			try {
				img = reader.acquireLatestImage();
				if (img == null) return;
				if (!mEisEnabled) { img.close(); return; }
				final android.media.Image captured = img;
				img = null;
				ExecutorService exec = mEisExecutor;
				if (exec != null && !exec.isShutdown()) {
					exec.execute(() -> processEisFrame(captured));
				} else {
					captured.close();
				}
			} catch (Throwable t) {
				if (img != null) try { img.close(); } catch (Exception ignored) {}
			}
		}, mCamHandler);
	}

	/**
	 * Обработка EIS кадра.
	 *
	 * Tracking: Y-плоскость → grayscale Mat → template matching (OpenCV).
	 * Display:  YUV → ARGB pixels (прямая конвертация, ~3ms) → Bitmap →
	 *           Matrix-трансформация (сдвиг + кроп) → ImageView.
	 * Recording: стабилизированные пиксели → ImageWriter → mEncSurface.
	 */
	private void processEisFrame(android.media.Image image) {
		try {
			int iw = image.getWidth();
			int ih = image.getHeight();

			android.media.Image.Plane[] planes = image.getPlanes();
			java.nio.ByteBuffer yBuf = planes[0].getBuffer();
			java.nio.ByteBuffer uBuf = planes[1].getBuffer();
			java.nio.ByteBuffer vBuf = planes[2].getBuffer();
			int yStride  = planes[0].getRowStride();
			int uvStride = planes[1].getRowStride();
			int uvPixel  = planes[1].getPixelStride();

			// ── 1. Y compact для tracking ─────────────────────────────────
			byte[] yCompact = new byte[iw * ih];
			if (yStride == iw) {
				yBuf.get(yCompact);
			} else {
				for (int row = 0; row < ih; row++) {
					yBuf.position(row * yStride);
					int n = Math.min(iw, yBuf.remaining());
					yBuf.get(yCompact, row * iw, n);
				}
			}

			// ── 2. YUV→ARGB int[] прямым расчётом (~3ms) ─────────────────
			int[] argb = new int[iw * ih];
			byte[] uRow = new byte[Math.max(uvStride, 1)];
			byte[] vRow = new byte[Math.max(uvStride, 1)];
			for (int row = 0; row < ih; row++) {
				int uvRow = row / 2;
				int uvN = Math.min(uvStride, uBuf.capacity() - uvRow * uvStride);
				if (uvN > 0) {
					uBuf.position(uvRow * uvStride);
					uBuf.get(uRow, 0, uvN);
					vBuf.position(uvRow * uvStride);
					vBuf.get(vRow, 0, Math.min(uvN, vBuf.remaining()));
				}
				for (int col = 0; col < iw; col++) {
					int Y = yCompact[row * iw + col] & 0xFF;
					int uvIdx = (col / 2) * uvPixel;
					int U = (uvIdx < uvN) ? (uRow[uvIdx] & 0xFF) - 128 : 0;
					int V = (uvIdx < uvN) ? (vRow[uvIdx] & 0xFF) - 128 : 0;
					int r = clamp(Y + (int)(1.402f * V));
					int g = clamp(Y - (int)(0.344f * U) - (int)(0.714f * V));
					int b = clamp(Y + (int)(1.772f * U));
					argb[row * iw + col] = 0xFF000000 | (r << 16) | (g << 8) | b;
				}
			}
			image.close();

			// ── 3. Mutable Bitmap через setPixels (ВСЕГДА mutable) ────────
			Bitmap rawBmp = Bitmap.createBitmap(iw, ih, Bitmap.Config.ARGB_8888);
			rawBmp.setPixels(argb, 0, iw, 0, 0, iw, ih);

			// ── 4. Поворот ─────────────────────────────────────────────────
			@SuppressWarnings("deprecation")
			int dispRot  = getWindowManager().getDefaultDisplay().getRotation() * 90;
			int rotAngle = (mSensorOrientation - dispRot + 360) % 360;
			Bitmap workBmp;
			if (rotAngle != 0) {
				android.graphics.Matrix m = new android.graphics.Matrix();
				m.postRotate(rotAngle);
				// Явно создаём mutable dest через Canvas
				Bitmap tmp = Bitmap.createBitmap(
					rotAngle == 90 || rotAngle == 270 ? ih : iw,
					rotAngle == 90 || rotAngle == 270 ? iw : ih,
					Bitmap.Config.ARGB_8888);
				android.graphics.Canvas cv0 = new android.graphics.Canvas(tmp);
				cv0.drawBitmap(rawBmp, m, null);
				rawBmp.recycle();
				workBmp = tmp;
			} else {
				workBmp = rawBmp;
			}
			int bW = workBmp.getWidth();
			int bH = workBmp.getHeight();

			// ── 5. Tracking: пирамида двух уровней ──────────────────────
			// Строим grayscale Mat в ориентации workBmp
			Mat trackGray = new Mat(ih, iw, CvType.CV_8UC1);
			trackGray.put(0, 0, yCompact);
			Mat trackRot = new Mat();
			if      (rotAngle == 90)  Core.rotate(trackGray, trackRot, Core.ROTATE_90_CLOCKWISE);
			else if (rotAngle == 270) Core.rotate(trackGray, trackRot, Core.ROTATE_90_COUNTERCLOCKWISE);
			else if (rotAngle == 180) Core.rotate(trackGray, trackRot, Core.ROTATE_180);
			else                      trackGray.copyTo(trackRot);
			trackGray.release();
			int tW = trackRot.cols(), tH = trackRot.rows();

			// L0: resize до 320×240 для грубого поиска
			final int L0W = 320, L0H = 240;
			Mat trackL0 = new Mat();
			Imgproc.resize(trackRot, trackL0, new org.opencv.core.Size(L0W, L0H));
			float scaleL0x = (float) tW / L0W;
			float scaleL0y = (float) tH / L0H;

			// ── 6. Инициализация трекера ──────────────────────────────────
			if (eisActualW == 0) {
				eisActualW    = tW;  eisActualH    = tH;
				eisIdealX     = (tW - eisTmplSize) / 2;
				eisIdealY     = (tH - eisTmplSize) / 2;
				eisVirtualX   = eisIdealX; eisVirtualY = eisIdealY;
				eisLastMatchX = eisIdealX; eisLastMatchY = eisIdealY;
				eisLastDx = 0; eisLastDy = 0;
			}
			// Шаблон всегда на L0
			final int tmplL0 = Math.max(20, eisTmplSize * L0W / tW);
			final int idealL0x = L0W / 2 - tmplL0 / 2;
			final int idealL0y = L0H / 2 - tmplL0 / 2;

			if (eisTemplate == null) {
				eisRefFrame = trackL0.clone();
				eisTemplate = new Mat(eisRefFrame,
					new org.opencv.core.Rect(idealL0x, idealL0y, tmplL0, tmplL0)).clone();
				// Сохраняем позицию в L0-координатах
				eisLastMatchX = (int)(eisIdealX / scaleL0x);
				eisLastMatchY = (int)(eisIdealY / scaleL0y);
			}
			if (mEisManualReset) {
				if (eisTemplate != null) eisTemplate.release();
				eisTemplate = new Mat(trackL0,
					new org.opencv.core.Rect(idealL0x, idealL0y, tmplL0, tmplL0)).clone();
				eisLastMatchX = idealL0x; eisLastMatchY = idealL0y;
				double cDx = eisLastMatchX - eisVirtualX / scaleL0x;
				double cDy = eisLastMatchY - eisVirtualY / scaleL0y;
				eisVirtualX = idealL0x - cDx;
				eisVirtualY = idealL0y - cDy;
				eisLastDx = 0; eisLastDy = 0;
				mEisManualReset = false;
			}

			// ── 7. L0 грубый поиск ────────────────────────────────────────
			double dx = eisLastDx, dy = eisLastDy;
			int matchL0x = eisLastMatchX, matchL0y = eisLastMatchY;

			final int srL0 = Math.max(20, SEARCH_RADIUS * L0W / tW);
			int r0X = Math.max(0, eisLastMatchX - srL0);
			int r0Y = Math.max(0, eisLastMatchY - srL0);
			int r0W = Math.min(L0W - r0X, tmplL0 + srL0 * 2);
			int r0H = Math.min(L0H - r0Y, tmplL0 + srL0 * 2);

			boolean goodMatch = false;
			if (r0W > tmplL0 && r0H > tmplL0) {
				Mat roi0 = new Mat(trackL0, new org.opencv.core.Rect(r0X, r0Y, r0W, r0H));
				Mat res0 = new Mat();
				Imgproc.matchTemplate(roi0, eisTemplate, res0, Imgproc.TM_CCOEFF_NORMED);
				Core.MinMaxLocResult mm0 = Core.minMaxLoc(res0);
				roi0.release(); res0.release();

				matchL0x = r0X + (int) mm0.maxLoc.x;
				matchL0y = r0Y + (int) mm0.maxLoc.y;
				double jumpL0 = Math.hypot(matchL0x - eisLastMatchX, matchL0y - eisLastMatchY);

				boolean edgeL0 =
					matchL0x < 2 || matchL0x + tmplL0 > L0W - 2 ||
					matchL0y < 2 || matchL0y + tmplL0 > L0H - 2;

				if (mm0.maxVal >= 0.35 && !edgeL0 && jumpL0 <= srL0 * 1.5) {

					// ── 7b. L1 уточнение на полном разрешении ─────────────
					// Переводим L0-позицию в full-res координаты
					int fineX = (int)(matchL0x * scaleL0x);
					int fineY = (int)(matchL0y * scaleL0y);
					int fineTmpl = eisTmplSize;
					final int fineROI = 32; // ±32px вокруг L0-позиции

					int r1X = Math.max(0, fineX - fineROI);
					int r1Y = Math.max(0, fineY - fineROI);
					int r1W = Math.min(tW - r1X, fineTmpl + fineROI * 2);
					int r1H = Math.min(tH - r1Y, fineTmpl + fineROI * 2);

					if (r1W > fineTmpl && r1H > fineTmpl) {
						// Строим шаблон в full-res из текущего idealX/idealY
						Mat tmplFull = new Mat(trackRot,
							new org.opencv.core.Rect(eisIdealX, eisIdealY, fineTmpl, fineTmpl));
						Mat roi1 = new Mat(trackRot, new org.opencv.core.Rect(r1X, r1Y, r1W, r1H));
						Mat res1 = new Mat();
						Imgproc.matchTemplate(roi1, tmplFull, res1, Imgproc.TM_CCOEFF_NORMED);
						Core.MinMaxLocResult mm1 = Core.minMaxLoc(res1);
						tmplFull.release(); roi1.release();

						int matchFineX = r1X + (int) mm1.maxLoc.x;
						int matchFineY = r1Y + (int) mm1.maxLoc.y;

						// Субпиксельная параболическая интерполяция по X
						double subX = matchFineX, subY = matchFineY;
						int cx = (int) mm1.maxLoc.x, cy = (int) mm1.maxLoc.y;
						if (cx > 0 && cx < res1.cols()-1 && cy > 0 && cy < res1.rows()-1) {
							double v0x = res1.get(cy, cx-1)[0];
							double v1x = res1.get(cy, cx  )[0];
							double v2x = res1.get(cy, cx+1)[0];
							double denom = v0x - 2*v1x + v2x;
							if (Math.abs(denom) > 1e-6) subX += r1X + cx - 0.5*(v2x-v0x)/denom;
							else subX = matchFineX;

							double v0y = res1.get(cy-1, cx)[0];
							double v2y = res1.get(cy+1, cx)[0];
							double denomY = v0y - 2*v1x + v2y;
							if (Math.abs(denomY) > 1e-6) subY += r1Y + cy - 0.5*(v2y-v0y)/denomY;
							else subY = matchFineY;
						}
						res1.release();

						eisLastMatchX = (int)(subX / scaleL0x); // обратно в L0 для след. кадра
						eisLastMatchY = (int)(subY / scaleL0y);

						eisVirtualX += (subX - eisVirtualX) * mEisDriftSpeed;
						eisVirtualY += (subY - eisVirtualY) * mEisDriftSpeed;
						dx = subX - eisVirtualX;
						dy = subY - eisVirtualY;
						eisLastDx = dx; eisLastDy = dy;
						goodMatch = true;
					}
				}
			}

			if (!goodMatch) {
				// Плохой кадр: обновляем L0-шаблон, offset не трогаем
				if (eisTemplate != null) eisTemplate.release();
				eisTemplate = new Mat(trackL0,
					new org.opencv.core.Rect(idealL0x, idealL0y, tmplL0, tmplL0)).clone();
				eisLastMatchX = idealL0x;
				eisLastMatchY = idealL0y;
				// dx/dy = eisLastDx/Dy — без прыжка
			}

			trackL0.release();
			trackRot.release();

			// ── 8. Стабилизация: crop + offset ───────────────────────────
			int offsetX = (int)(dx * (float) bW / tW);
			int offsetY = (int)(dy * (float) bH / tH);
			int cropW   = (int)(bW / eisZoom);
			int cropH   = (int)(bH / eisZoom);
			int cropL   = Math.max(0, Math.min((bW - cropW) / 2 + offsetX, bW - cropW));
			int cropT   = Math.max(0, Math.min((bH - cropH) / 2 + offsetY, bH - cropH));
			android.graphics.Rect srcRect = new android.graphics.Rect(
				cropL, cropT, cropL + cropW, cropT + cropH);

			// ── 9. Encoder bitmap: 9:16 кроп из 3:4, нативный 1:1 ──────────
			// Источник после поворота: bW=960, bH=1280 (3:4 портрет).
			// Для 9:16 портрета: encCropW = bH * 9/16 = 720, encCropH = bH = 1280.
			// После разворота → 1280×720 (landscape) = mEisEncW×mEisEncH — нулевой upscale.
			Bitmap encBmp = null;
			if (mRecording && mEisEncReady && mEisVidEnc != null) {
				int encCropH = bH;                          // 1280
				int encCropW = encCropH * 9 / 16;          // 720
				int encCropL = Math.max(0, Math.min((bW - encCropW) / 2 + (int)(offsetX * bW / bH * 16 / 9), bW - encCropW));
				int encCropT = Math.max(0, Math.min((int)(offsetY), bH - encCropH));

				Bitmap cropBmp = Bitmap.createBitmap(encCropW, encCropH, Bitmap.Config.ARGB_8888);
				new android.graphics.Canvas(cropBmp).drawBitmap(workBmp,
					new android.graphics.Rect(encCropL, encCropT, encCropL+encCropW, encCropT+encCropH),
					new android.graphics.Rect(0, 0, encCropW, encCropH), null);

				// Разворачиваем обратно в landscape — результат 1280×720 или 720×1280
				// Принудительно выравниваем в landscape (ширина > высота)
				int backAngle = (360 - rotAngle) % 360;
				Bitmap stabBmp;
				if (backAngle != 0) {
					android.graphics.Matrix mSt = new android.graphics.Matrix();
					mSt.postRotate(backAngle);
					stabBmp = Bitmap.createBitmap(cropBmp, 0, 0, encCropW, encCropH, mSt, false);
					cropBmp.recycle();
				} else {
					stabBmp = cropBmp;
				}
				// Если после разворота всё ещё портрет — поворачиваем ещё раз
				if (stabBmp.getHeight() > stabBmp.getWidth()) {
					android.graphics.Matrix mFix = new android.graphics.Matrix();
					mFix.postRotate(90);
					Bitmap fixed = Bitmap.createBitmap(stabBmp, 0, 0,
						stabBmp.getWidth(), stabBmp.getHeight(), mFix, false);
					stabBmp.recycle();
					stabBmp = fixed;
				}
				// Нативный размер уже mEisEncW×mEisEncH — никакого масштабирования
				encBmp = stabBmp;
			}
			float sx = (float) bW / tW, sy = (float) bH / tH;
			// Позиция шаблона в full-res координатах для отрисовки рамок
			int matchX = (int)(eisLastMatchX * scaleL0x);
			int matchY = (int)(eisLastMatchY * scaleL0y);
			android.graphics.Canvas cvUI = new android.graphics.Canvas(workBmp);
			android.graphics.Paint pnt = new android.graphics.Paint();
			pnt.setStyle(android.graphics.Paint.Style.STROKE);
			pnt.setAntiAlias(false);
			if (eisGhostOffX != null) {
				pnt.setColor(android.graphics.Color.YELLOW);
				pnt.setStrokeWidth(1.5f);
				cvUI.drawRect(
					(matchX + eisGhostOffX) * sx, (matchY + eisGhostOffY) * sy,
					(matchX + eisGhostOffX + eisTmplSize) * sx,
					(matchY + eisGhostOffY + eisTmplSize) * sy, pnt);
			}
			pnt.setColor(android.graphics.Color.RED);
			pnt.setStrokeWidth(2f);
			cvUI.drawRect(matchX * sx, matchY * sy,
				(matchX + eisTmplSize) * sx, (matchY + eisTmplSize) * sy, pnt);

			// ── 11. Display bitmap: с рамками, cropW×cropH ───────────────
			Bitmap dispBmp = Bitmap.createBitmap(cropW, cropH, Bitmap.Config.ARGB_8888);
			new android.graphics.Canvas(dispBmp).drawBitmap(workBmp, srcRect,
				new android.graphics.Rect(0, 0, cropW, cropH), null);
			workBmp.recycle();

			// ── 12. Запись в EIS encoder ──────────────────────────────────
			if (encBmp != null) {
				feedEisEncoder(encBmp);
				encBmp.recycle();
			}

			// ── 13. Display ────────────────────────────────────────────────
			final Bitmap finalBmp = dispBmp;
			runOnUiThread(() -> {
				if (mEisView != null && mEisEnabled)
					mEisView.setImageBitmap(finalBmp);
			});

		} catch (Throwable t) {
			try { image.close(); } catch (Throwable ignored) {}
			String msg = t.getClass().getSimpleName() + ": " + t.getMessage();
			runOnUiThread(() -> status("EIS: " + msg));
		}
	}


	private static int clamp(int v) {
		return v < 0 ? 0 : (v > 255 ? 255 : v);
	}

	private void triggerSmoothReset(Mat grayFrame) {
		if (eisTemplate == null) return;
		eisGhostOffX = eisLastMatchX - eisIdealX;
		eisGhostOffY = eisLastMatchY - eisIdealY;
		double currentDx = eisLastMatchX - eisVirtualX;
		double currentDy = eisLastMatchY - eisVirtualY;
		eisTemplate.release();
		eisTemplate = new Mat(grayFrame,
			new org.opencv.core.Rect(eisIdealX, eisIdealY, eisTmplSize, eisTmplSize)).clone();
		eisVirtualX   = eisIdealX - currentDx;
		eisVirtualY   = eisIdealY - currentDy;
		eisLastMatchX = eisIdealX;
		eisLastMatchY = eisIdealY;
	}

	// =========================================================================
	// EIS Encoder (Variant B: Bitmap → NV21 ByteBuffer → MediaCodec H.264)
	// =========================================================================

	private volatile boolean mEglReady = false;
	private void eisLog(String msg) {
		android.util.Log.d("EIS", msg);
	}

	private int mEisEncW = VIDEO_W;
	private int mEisEncH = VIDEO_H;
	private int mEisRotHint = 0;
	private int mEisReaderW = 640;  // SD по умолчанию
	private int mEisReaderH = 480;

	// EGL — инициализируется лениво в EIS-треде при первом feedEisEncoder
	private android.opengl.EGLDisplay mEglDisplay = android.opengl.EGL14.EGL_NO_DISPLAY;
	private android.opengl.EGLContext mEglContext  = android.opengl.EGL14.EGL_NO_CONTEXT;
	private android.opengl.EGLSurface mEglSurface  = android.opengl.EGL14.EGL_NO_SURFACE;
	private int  mEglProgram  = 0;
	private int  mEglTexture  = 0;
	private long mEisStartNs  = 0;

	private void startEisEncoder() {
		stopEisEncoder();
		mEglReady = false;
		try {
			// Encoder всегда landscape VIDEO_W×VIDEO_H — как оригинальный SimpleCam.
			// Ориентация задаётся через setOrientationHint мюксера.
			mEisEncW = VIDEO_W;  // 1280
			mEisEncH = VIDEO_H;  // 720
			eisLog("encoder size=" + mEisEncW + "x" + mEisEncH);

			MediaFormat vf = MediaFormat.createVideoFormat(
				MediaFormat.MIMETYPE_VIDEO_AVC, mEisEncW, mEisEncH);
			vf.setInteger(MediaFormat.KEY_BIT_RATE, mVideoBps);
			vf.setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS);
			vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 0); // частые I-frames = нет артефактов в начале
			vf.setInteger(MediaFormat.KEY_COLOR_FORMAT,
				CodecCapabilities.COLOR_FormatSurface);
			// High profile + уровень 4.1 = лучшее качество, поддерживается всеми Android 5+
			vf.setInteger(MediaFormat.KEY_PROFILE, CodecProfileLevel.AVCProfileHigh);
			vf.setInteger(MediaFormat.KEY_LEVEL,   CodecProfileLevel.AVCLevel41);
			mEisVidEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
			mEisVidEnc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
			mEisInputSurface = mEisVidEnc.createInputSurface();
			mEisVidEnc.start();
			mEisVidOutFmt = null;
			mEisEncReady  = false;
			mEisStartNs   = System.nanoTime();
			eisLog("MediaCodec started, waiting drain thread");

			Thread t = new Thread(this::drainEisEncoder, "eis-drain");
			t.setDaemon(true); t.start();

			// EGL будет инициализирован лениво в EIS-треде при первом feedEisEncoder.
			// Kick-кадр: отправляем в EIS executor — он же и проинициализирует EGL.
			ExecutorService exec = mEisExecutor;
			if (exec != null && !exec.isShutdown()) {
				exec.execute(() -> {
					eisLog("kick: initEgl in EIS thread");
					initEgl(mEisInputSurface);
					mEglReady = true;
					drawBitmapEgl(null); // чёрный кадр → INFO_OUTPUT_FORMAT_CHANGED
					eisLog("kick: black frame sent");
				});
			}
		} catch (Exception e) {
			eisLog("startEisEncoder FAILED: " + e);
			releaseEgl();
			mEisVidEnc = null; mEisInputSurface = null;
		}
	}

	private void stopEisEncoder() {
		mEisEncReady = false;
		mEglReady    = false;
		// releaseEgl должен быть вызван из EIS-треда (тот же тред что делал initEgl)
		ExecutorService exec = mEisExecutor;
		if (exec != null && !exec.isShutdown()) {
			try {
				exec.submit(this::releaseEgl).get(1, java.util.concurrent.TimeUnit.SECONDS);
			} catch (Exception ignored) {}
		} else {
			releaseEgl();
		}
		MediaCodec enc = mEisVidEnc;
		android.view.Surface surf = mEisInputSurface;
		mEisVidEnc = null; mEisInputSurface = null;
		if (enc != null) {
			try { enc.signalEndOfInputStream(); } catch (Exception ignored) {}
			try { Thread.sleep(150); } catch (Exception ignored) {}
			try { enc.stop(); enc.release(); } catch (Exception ignored) {}
		}
		if (surf != null) try { surf.release(); } catch (Exception ignored) {}
	}

	/** EIS executor thread — EGL context current. Bitmap должен быть mEisEncW×mEisEncH. */
	private void feedEisEncoder(Bitmap bmp) {
		if (!mEglReady) return;
		// Bitmap уже правильного размера — GPU рисует 1:1, никакого масштабирования
		drawBitmapEgl(bmp);
	}

	// ── EGL/GLES internals ────────────────────────────────────────────────────

	private static final String VERT_SRC =
		"attribute vec4 aPos;\n" +
		"attribute vec2 aTex;\n" +
		"varying vec2 vTex;\n" +
		"void main(){gl_Position=aPos;vTex=aTex;}";

	private static final String FRAG_SRC =
		"precision mediump float;\n" +
		"uniform sampler2D uTex;\n" +
		"varying vec2 vTex;\n" +
		"void main(){gl_FragColor=texture2D(uTex,vTex);}";

	private void initEgl(android.view.Surface surface) {
		mEglDisplay = android.opengl.EGL14.eglGetDisplay(
			android.opengl.EGL14.EGL_DEFAULT_DISPLAY);
		int[] ver = new int[2];
		android.opengl.EGL14.eglInitialize(mEglDisplay, ver, 0, ver, 1);

		int[] attribs = {
			android.opengl.EGL14.EGL_RED_SIZE,   8,
			android.opengl.EGL14.EGL_GREEN_SIZE, 8,
			android.opengl.EGL14.EGL_BLUE_SIZE,  8,
			android.opengl.EGL14.EGL_RENDERABLE_TYPE,
				android.opengl.EGL14.EGL_OPENGL_ES2_BIT,
			android.opengl.EGLExt.EGL_RECORDABLE_ANDROID, 1,
			android.opengl.EGL14.EGL_NONE
		};
		android.opengl.EGLConfig[] configs = new android.opengl.EGLConfig[1];
		int[] numConfigs = new int[1];
		android.opengl.EGL14.eglChooseConfig(mEglDisplay, attribs, 0,
			configs, 0, 1, numConfigs, 0);

		int[] ctxAttribs = {
			android.opengl.EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
			android.opengl.EGL14.EGL_NONE
		};
		mEglContext = android.opengl.EGL14.eglCreateContext(
			mEglDisplay, configs[0],
			android.opengl.EGL14.EGL_NO_CONTEXT, ctxAttribs, 0);

		int[] surfAttribs = { android.opengl.EGL14.EGL_NONE };
		mEglSurface = android.opengl.EGL14.eglCreateWindowSurface(
			mEglDisplay, configs[0], surface, surfAttribs, 0);

		android.opengl.EGL14.eglMakeCurrent(
			mEglDisplay, mEglSurface, mEglSurface, mEglContext);

		// Compile shader program
		mEglProgram = buildProgram(VERT_SRC, FRAG_SRC);

		// Allocate texture
		int[] tex = new int[1];
		android.opengl.GLES20.glGenTextures(1, tex, 0);
		mEglTexture = tex[0];
		android.opengl.GLES20.glBindTexture(
			android.opengl.GLES20.GL_TEXTURE_2D, mEglTexture);
		android.opengl.GLES20.glTexParameteri(
			android.opengl.GLES20.GL_TEXTURE_2D,
			android.opengl.GLES20.GL_TEXTURE_MIN_FILTER,
			android.opengl.GLES20.GL_LINEAR);
		android.opengl.GLES20.glTexParameteri(
			android.opengl.GLES20.GL_TEXTURE_2D,
			android.opengl.GLES20.GL_TEXTURE_MAG_FILTER,
			android.opengl.GLES20.GL_LINEAR);
		// Без повтора текстуры
		android.opengl.GLES20.glTexParameteri(
			android.opengl.GLES20.GL_TEXTURE_2D,
			android.opengl.GLES20.GL_TEXTURE_WRAP_S,
			android.opengl.GLES20.GL_CLAMP_TO_EDGE);
		android.opengl.GLES20.glTexParameteri(
			android.opengl.GLES20.GL_TEXTURE_2D,
			android.opengl.GLES20.GL_TEXTURE_WRAP_T,
			android.opengl.GLES20.GL_CLAMP_TO_EDGE);
	}

	private void drawBitmapEgl(Bitmap bmp) {
		if (mEglDisplay == android.opengl.EGL14.EGL_NO_DISPLAY) return;

		android.opengl.GLES20.glViewport(0, 0, mEisEncW, mEisEncH);
		android.opengl.GLES20.glClearColor(0, 0, 0, 1);
		android.opengl.GLES20.glClear(android.opengl.GLES20.GL_COLOR_BUFFER_BIT);

		if (bmp != null) {
			android.opengl.GLES20.glBindTexture(
				android.opengl.GLES20.GL_TEXTURE_2D, mEglTexture);
			android.opengl.GLUtils.texImage2D(
				android.opengl.GLES20.GL_TEXTURE_2D, 0, bmp, 0);

			android.opengl.GLES20.glUseProgram(mEglProgram);

			// Full-screen quad: positions + UVs
			float[] verts = { -1,-1, 0,1,  1,-1, 1,1,  -1,1, 0,0,  1,1, 1,0 };
			java.nio.FloatBuffer fb = java.nio.ByteBuffer
				.allocateDirect(verts.length * 4)
				.order(java.nio.ByteOrder.nativeOrder())
				.asFloatBuffer();
			fb.put(verts).position(0);

			int aPos = android.opengl.GLES20.glGetAttribLocation(mEglProgram, "aPos");
			int aTex = android.opengl.GLES20.glGetAttribLocation(mEglProgram, "aTex");
			int uTex = android.opengl.GLES20.glGetUniformLocation(mEglProgram, "uTex");

			android.opengl.GLES20.glEnableVertexAttribArray(aPos);
			fb.position(0);
			android.opengl.GLES20.glVertexAttribPointer(aPos, 2,
				android.opengl.GLES20.GL_FLOAT, false, 16, fb);

			android.opengl.GLES20.glEnableVertexAttribArray(aTex);
			fb.position(2);
			android.opengl.GLES20.glVertexAttribPointer(aTex, 2,
				android.opengl.GLES20.GL_FLOAT, false, 16, fb);

			android.opengl.GLES20.glUniform1i(uTex, 0);
			android.opengl.GLES20.glDrawArrays(
				android.opengl.GLES20.GL_TRIANGLE_STRIP, 0, 4);
		}

		// PTS: наносекунды от старта записи
		long ptsNs = System.nanoTime() - mEisStartNs;
		android.opengl.EGLExt.eglPresentationTimeANDROID(
			mEglDisplay, mEglSurface, ptsNs);
		android.opengl.EGL14.eglSwapBuffers(mEglDisplay, mEglSurface);
	}

	private void releaseEgl() {
		if (mEglDisplay != android.opengl.EGL14.EGL_NO_DISPLAY) {
			android.opengl.EGL14.eglMakeCurrent(mEglDisplay,
				android.opengl.EGL14.EGL_NO_SURFACE,
				android.opengl.EGL14.EGL_NO_SURFACE,
				android.opengl.EGL14.EGL_NO_CONTEXT);
			if (mEglSurface != android.opengl.EGL14.EGL_NO_SURFACE)
				android.opengl.EGL14.eglDestroySurface(mEglDisplay, mEglSurface);
			if (mEglContext != android.opengl.EGL14.EGL_NO_CONTEXT)
				android.opengl.EGL14.eglDestroyContext(mEglDisplay, mEglContext);
			android.opengl.EGL14.eglReleaseThread();
			android.opengl.EGL14.eglTerminate(mEglDisplay);
		}
		mEglDisplay = android.opengl.EGL14.EGL_NO_DISPLAY;
		mEglContext = android.opengl.EGL14.EGL_NO_CONTEXT;
		mEglSurface = android.opengl.EGL14.EGL_NO_SURFACE;
		if (mEglTexture != 0) {
			android.opengl.GLES20.glDeleteTextures(1, new int[]{mEglTexture}, 0);
			mEglTexture = 0;
		}
		if (mEglProgram != 0) {
			android.opengl.GLES20.glDeleteProgram(mEglProgram);
			mEglProgram = 0;
		}
	}

	private static int buildProgram(String vertSrc, String fragSrc) {
		int v = android.opengl.GLES20.glCreateShader(
			android.opengl.GLES20.GL_VERTEX_SHADER);
		android.opengl.GLES20.glShaderSource(v, vertSrc);
		android.opengl.GLES20.glCompileShader(v);
		int f = android.opengl.GLES20.glCreateShader(
			android.opengl.GLES20.GL_FRAGMENT_SHADER);
		android.opengl.GLES20.glShaderSource(f, fragSrc);
		android.opengl.GLES20.glCompileShader(f);
		int p = android.opengl.GLES20.glCreateProgram();
		android.opengl.GLES20.glAttachShader(p, v);
		android.opengl.GLES20.glAttachShader(p, f);
		android.opengl.GLES20.glLinkProgram(p);
		android.opengl.GLES20.glDeleteShader(v);
		android.opengl.GLES20.glDeleteShader(f);
		return p;
	}

	private void drainEisEncoder() {
		eisLog("drain: thread started");
		MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
		int errCount = 0;
		int frameCount = 0;
		while (true) {
			MediaCodec enc = mEisVidEnc;
			if (enc == null) { eisLog("drain: enc=null, exit"); break; }
			int out;
			try {
				out = enc.dequeueOutputBuffer(info, 40_000);
				errCount = 0;
			} catch (Exception e) {
				if (++errCount > 10) {
					eisLog("drain: fatal after 10 errors: " + e);
					break;
				}
				try { Thread.sleep(10); } catch (Exception ignored) {}
				continue;
			}
			if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
				mEisVidOutFmt = enc.getOutputFormat();
				eisLog("drain: FORMAT_CHANGED → " + mEisVidOutFmt);
				synchronized (this) { notifyAll(); }
				continue;
			}
			if (out == MediaCodec.INFO_TRY_AGAIN_LATER) continue;
			if (out < 0) { eisLog("drain: unknown out=" + out); continue; }
			boolean cfg = (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0;
			boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
			try {
				if (!cfg && info.size > 0) {
					if (mMuxReady && mEisVidTrack >= 0) {
						ByteBuffer data = enc.getOutputBuffer(out);
						MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
						bi.set(info.offset, info.size, info.presentationTimeUs,
							info.flags & ~MediaCodec.BUFFER_FLAG_END_OF_STREAM);
						synchronized (mMuxLock) {
							if (mMuxReady && mEisVidTrack >= 0) {
								mMuxer.writeSampleData(mEisVidTrack, data, bi);
								frameCount++;
								if (frameCount <= 3 || frameCount % 30 == 0)
									eisLog("drain: wrote frame " + frameCount
										+ " pts=" + info.presentationTimeUs);
							}
						}
					} else {
						eisLog("drain: mux not ready yet, mMuxReady=" + mMuxReady
							+ " track=" + mEisVidTrack);
					}
				}
			} catch (Exception e) {
				eisLog("drain: mux error: " + e);
			} finally {
				try { enc.releaseOutputBuffer(out, false); } catch (Exception ignored) {}
			}
			if (eos) { eisLog("drain: EOS, total frames=" + frameCount); break; }
		}
	}

	// =========================================================================
	// WAV parallel recording

	// =========================================================================

	private void startWavWriter(int channels) {
		if (!mWriteWav) return;
		try {
			File cache = getExternalCacheDir();
			if (cache == null) cache = getCacheDir();
			mWavTempFile = new File(cache, "eis_audio_" + System.currentTimeMillis() + ".wav");
			mWavFos = new java.io.FileOutputStream(mWavTempFile);
			mWavTotalPcmBytes = 0;
			writeWavHeader(mWavFos, channels, AUDIO_SR, 16, 0); // placeholder size
		} catch (Exception e) {
			status("WAV open err: " + e.getMessage());
			mWavFos = null;
		}
	}

	/** Пишет блок PCM в WAV-файл. Вызывается из audioMainLoop. */
	void writeWavPcm(short[] buf, int len) {
		java.io.FileOutputStream fos = mWavFos;
		if (fos == null) return;
		try {
			byte[] bytes = new byte[len * 2];
			for (int i = 0; i < len; i++) {
				bytes[i * 2]     = (byte)(buf[i] & 0xFF);
				bytes[i * 2 + 1] = (byte)(buf[i] >> 8 & 0xFF);
			}
			fos.write(bytes);
			mWavTotalPcmBytes += bytes.length;
		} catch (Exception ignored) {}
	}

	void finalizeWavWriter() {
		java.io.FileOutputStream fos = mWavFos;
		mWavFos = null;
		if (fos == null || mWavTempFile == null) return;
		try {
			fos.close();
			// Обновляем заголовок с реальными размерами
			try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(mWavTempFile, "rw")) {
				int ch = mAudChannels;
				long dataLen  = mWavTotalPcmBytes;
				long chunkLen = dataLen + 36;
				raf.seek(4);  writeInt32LE(raf, (int) chunkLen);
				raf.seek(40); writeInt32LE(raf, (int) dataLen);
			}
			// Сохраняем в галерею
			String name = "SimpleCam_Audio_" + System.currentTimeMillis() + ".wav";
			if (Build.VERSION.SDK_INT >= 29) {
				ContentValues cv = new ContentValues();
				cv.put(MediaStore.Audio.Media.DISPLAY_NAME, name);
				cv.put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav");
				cv.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/CaMic");
				Uri uri = getContentResolver().insert(
					MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv);
				if (uri != null) {
					try (java.io.OutputStream os =
							getContentResolver().openOutputStream(uri);
						java.io.InputStream is =
							new java.io.FileInputStream(mWavTempFile)) {
						byte[] b = new byte[8192]; int n;
						while ((n = is.read(b)) != -1) os.write(b, 0, n);
					}
				}
			}
			mWavTempFile.delete();
			mWavTempFile = null;
			status("WAV saved: " + name);
		} catch (Exception e) {
			status("WAV finalize err: " + e.getMessage());
		}
	}

	private static void writeWavHeader(java.io.OutputStream out,
			int channels, int sampleRate, int bitsPerSample, long dataLen)
			throws java.io.IOException {
		int byteRate  = sampleRate * channels * bitsPerSample / 8;
		int blockAlign = channels * bitsPerSample / 8;
		long chunkSize = dataLen + 36;
		byte[] h = new byte[44];
		// RIFF
		h[0]='R';h[1]='I';h[2]='F';h[3]='F';
		putLE32(h, 4, (int) chunkSize);
		h[8]='W';h[9]='A';h[10]='V';h[11]='E';
		// fmt
		h[12]='f';h[13]='m';h[14]='t';h[15]=' ';
		putLE32(h,16,16); putLE16(h,20,1); putLE16(h,22,channels);
		putLE32(h,24,sampleRate); putLE32(h,28,byteRate);
		putLE16(h,32,blockAlign); putLE16(h,34,bitsPerSample);
		// data
		h[36]='d';h[37]='a';h[38]='t';h[39]='a';
		putLE32(h,40,(int) dataLen);
		out.write(h);
	}

	private static void putLE32(byte[] b, int off, int v) {
		b[off]=(byte)v; b[off+1]=(byte)(v>>8); b[off+2]=(byte)(v>>16); b[off+3]=(byte)(v>>24);
	}
	private static void putLE16(byte[] b, int off, int v) {
		b[off]=(byte)v; b[off+1]=(byte)(v>>8);
	}
	private static void writeInt32LE(java.io.RandomAccessFile f, int v) throws java.io.IOException {
		f.write(v&0xFF); f.write((v>>8)&0xFF); f.write((v>>16)&0xFF); f.write((v>>24)&0xFF);
	}

	// =========================================================================
	// REC / STOP
	// =========================================================================

	private void onPauseClick() {
		mPaused = !mPaused;
		if (mPaused) {
			// Пауза: переводим в RING, кольца очищаем
			mPauseStartNano = System.nanoTime();
			mVidWriteMode = 0;
			mAudWriteMode = 0;
			synchronized(mVidRingLock) { mVidRing.clear(); }
			synchronized(mAudRingLock) { mAudRing.clear(); }
			mBtnPause.setText("▶");
			mBtnPause.setBackground(makeOval(0xFF228833));
			status("⏸ Paused");
		} else {
			// Снятие с паузы: LIVE сразу, без пре-буфера
			// mMuxBasePts сдвигаем: следующий фрейм будет записан с текущим PTS минус BasePts
			// Корректируем BasePts так, чтобы не было прыжка PTS в файле.
			// Самый простой способ: выставить mVidWriteMode=2 и mAudWriteMode=2 напрямую.
			// PTS коррекция: запоминаем момент паузы и момент возобновления,
			// сдвигаем BasePts на длину паузы.
			mPauseEndNano = System.nanoTime();
			long pauseDurUs = (mPauseEndNano - mPauseStartNano) / 1000L;
			mMuxBasePts += pauseDurUs; // вычитаем паузу из всех будущих PTS
			mVidWriteMode = 2; // LIVE
			mAudWriteMode = 2;
			mBtnPause.setText("⏸");
			mBtnPause.setBackground(mBtnBgPause);
			status("● REC (resumed)");
		}
	}

	private void onRecordClick() {
		if (mRecording) {
			mRecording = false;
			mBtn.setEnabled(false);
			status("Stopping…");
			new Thread(this::doStop).start();
		} else {
			mBtn.setEnabled(false);
			status("Starting…");
			new Thread(this::doStart).start();
		}
	}
	
	// =========================================================================
	// Запуск записи
	// =========================================================================
	

	// =========================================================================
	// Энкодеры: создание / видео-петля
	// =========================================================================

	/** Идемпотентно создаёт видео+аудио энкодеры и запускает videoPreviewLoop. */
	private synchronized void ensureEncoders() {
		// Видео-энкодер
		if (mVidEnc == null || mEncSurface == null || !mEncSurface.isValid()) {
			try {
				if (mVidEnc != null) { try{mVidEnc.stop();mVidEnc.release();}catch(Exception e){} mVidEnc=null; }
				if (mEncSurface != null) { try{mEncSurface.release();}catch(Exception e){} mEncSurface=null; }
				MediaFormat vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, VIDEO_W, VIDEO_H);
				vf.setInteger(MediaFormat.KEY_BIT_RATE, mVideoBps);
				vf.setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS);
				vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
				vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, CodecCapabilities.COLOR_FormatSurface);
				vf.setInteger(MediaFormat.KEY_PROFILE, CodecProfileLevel.AVCProfileBaseline);
				vf.setInteger(MediaFormat.KEY_LEVEL, CodecProfileLevel.AVCLevel31);
				mVidEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
				mVidEnc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
				mEncSurface = mVidEnc.createInputSurface();
				mVidEnc.start();
				mVidOutFmt = null;
				synchronized(mVidRingLock) { mVidRing.clear(); }
				mVidWriteMode = 0;
			} catch (Exception e) { status("VidEnc err: " + e.getMessage()); return; }
		}
		// Видео-петля
		if (!mVidLoopRunning) {
			Thread t = new Thread(this::videoPreviewLoop, "vid-preview");
			t.setDaemon(true); t.start();
		}
	}

	/**
	 * Непрерывно дренирует видео-энкодер.
	 * Переключение RING→FLUSH→LIVE происходит ЗДЕСЬ, в этом же потоке —
	 * никаких гонок, никаких пропущенных фреймов между кольцом и файлом.
	 */
	private void videoPreviewLoop() {
		mVidLoopRunning = true;
		MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
		while (mVidLoopRunning) {
			MediaCodec enc = mVidEnc;
			if (enc == null) { try{Thread.sleep(20);}catch(Exception e){} continue; }
			int out;
			try { out = enc.dequeueOutputBuffer(info, 40_000); }
			catch (Exception e) { break; }

			if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
				synchronized(mVidRingLock) { mVidOutFmt = enc.getOutputFormat(); }
				continue;
			}
			if (out < 0) continue;

			try {
				boolean cfg = (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0;
				if (cfg || info.size <= 0) continue;
				ByteBuffer data = enc.getOutputBuffer(out);
				int mode = mVidWriteMode;

				if (mode == 0) {
					// ── RING: добавляем в кольцо, обрезаем по mPreBufSecs ──
					EncodedFrame f = new EncodedFrame(data, info);
					synchronized(mVidRingLock) {
						mVidRing.addLast(f);
						while (mVidRing.size() > 1) {
							long span = mVidRing.peekLast().pts - mVidRing.peekFirst().pts;
							if (span <= (long) mPreBufSecs * 1_200_000L) break;
							mVidRing.removeFirst();
						}
					}
				} else if (mode == 1) {
					// ── FLUSH: сбрасываем кольцо в мюксер, затем текущий кадр ──
					// Всё делаем здесь — атомарно, в одном потоке.
					synchronized(mVidRingLock) {
						// Пропускаем до первого I-frame
						boolean foundKey = false;
						for (EncodedFrame rf : mVidRing) {
							if (!foundKey && !rf.isKey()) continue;
							foundKey = true;
							ByteBuffer rb = ByteBuffer.wrap(rf.data);
							MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
							bi.set(0, rf.data.length, rf.pts - mMuxBasePts, rf.flags);
							synchronized(mMuxLock) { if (mMuxReady) mMuxer.writeSampleData(mVidTrack, rb, bi); }
						}
						mVidRing.clear();
					}
					// Текущий кадр — первый живой
					MediaCodec.BufferInfo n = new MediaCodec.BufferInfo();
					n.set(info.offset, info.size, info.presentationTimeUs - mMuxBasePts, info.flags);
					synchronized(mMuxLock) { if (mMuxReady) mMuxer.writeSampleData(mVidTrack, data, n); }
					mVidWriteMode = 2; // LIVE
				} else {
					// ── LIVE: прямо в мюксер ──
					MediaCodec.BufferInfo n = new MediaCodec.BufferInfo();
					n.set(info.offset, info.size, info.presentationTimeUs - mMuxBasePts, info.flags);
					synchronized(mMuxLock) { if (mMuxReady) mMuxer.writeSampleData(mVidTrack, data, n); }
				}
			} finally { enc.releaseOutputBuffer(out, false); }
		}
		mVidLoopRunning = false;
	}

	// =========================================================================
	// Аудио-пайплайн
	// =========================================================================

	@SuppressLint("MissingPermission")
	private void startMonitor() {
		if (mAudRunning || !mPermsOk) return;
		int pos = mSpinner.getSelectedItemPosition();
		AudioSrcItem src2 = (pos >= 0 && pos < mSrcList.size()) ? mSrcList.get(pos) : null;
		int audioSrc = src2 != null ? src2.audioSource : MediaRecorder.AudioSource.MIC;

		int chanCfg = AudioFormat.CHANNEL_IN_STEREO; int channels = 2;
		int minBuf = AudioRecord.getMinBufferSize(AUDIO_SR, chanCfg, AudioFormat.ENCODING_PCM_16BIT);
		if (minBuf <= 0) { chanCfg = AudioFormat.CHANNEL_IN_MONO; channels = 1;
			minBuf = AudioRecord.getMinBufferSize(AUDIO_SR, chanCfg, AudioFormat.ENCODING_PCM_16BIT); }
		int bufSize = Math.max(minBuf, AUDIO_SR * channels * 2 / 5);
		AudioRecord rec = new AudioRecord(audioSrc, AUDIO_SR, chanCfg, AudioFormat.ENCODING_PCM_16BIT, bufSize);
		if (rec.getState() != AudioRecord.STATE_INITIALIZED && channels == 2) {
			rec.release(); chanCfg = AudioFormat.CHANNEL_IN_MONO; channels = 1;
			minBuf = AudioRecord.getMinBufferSize(AUDIO_SR, chanCfg, AudioFormat.ENCODING_PCM_16BIT);
			bufSize = Math.max(minBuf, AUDIO_SR * 2 / 5);
			rec = new AudioRecord(audioSrc, AUDIO_SR, chanCfg, AudioFormat.ENCODING_PCM_16BIT, bufSize);
		}
		if (rec.getState() != AudioRecord.STATE_INITIALIZED) { rec.release(); return; }
		if (Build.VERSION.SDK_INT >= 23 && src2 != null && src2.device != null)
			rec.setPreferredDevice(src2.device);
		disableAudioEffects(rec.getAudioSessionId());
		mAudRec = rec; mAudChannels = channels;

		// Создаём аудио-энкодер
		try {
			MediaFormat af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, AUDIO_SR, channels);
			af.setInteger(MediaFormat.KEY_BIT_RATE, channels == 1 ? 192_000 : 320_000);
			af.setInteger(MediaFormat.KEY_AAC_PROFILE, CodecProfileLevel.AACObjectLC);
			mAudEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
			mAudEnc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
			mAudEnc.start();
			mAudOutFmt = null;
			synchronized(mAudRingLock) { mAudRing.clear(); }
			mAudWriteMode = 0;
		} catch (Exception e) { status("AudEnc err: " + e.getMessage()); mAudEnc = null; }

		mAudRunning = true;
		mAudThread = new Thread(this::audioMainLoop, "aud-main");
		mAudThread.setDaemon(true); mAudThread.start();
	}

	private void stopAudio() {
		mAudRunning = false;
		if (mAudRec != null) try { mAudRec.stop(); } catch (Exception ignored) {}
		if (mAudThread != null) { try { mAudThread.join(600); } catch (Exception ignored) {} mAudThread = null; }
		if (mAudRec != null) { try { mAudRec.release(); } catch (Exception ignored) {} mAudRec = null; }
		if (mAudEnc != null) { try { mAudEnc.stop(); mAudEnc.release(); } catch (Exception ignored) {} mAudEnc = null; }
		mAudOutFmt = null;
		synchronized(mAudRingLock) { mAudRing.clear(); }
	}

	private void disableAudioEffects(int sid) {
		try { if (AutomaticGainControl.isAvailable()) { AutomaticGainControl a = AutomaticGainControl.create(sid); if (a!=null){a.setEnabled(false);a.release();} } } catch (Exception ignored) {}
		try { if (NoiseSuppressor.isAvailable()) { NoiseSuppressor n = NoiseSuppressor.create(sid); if (n!=null){n.setEnabled(false);n.release();} } } catch (Exception ignored) {}
		try { if (AcousticEchoCanceler.isAvailable()) { AcousticEchoCanceler e = AcousticEchoCanceler.create(sid); if (e!=null){e.setEnabled(false);e.release();} } } catch (Exception ignored) {}
	}

	/**
	 * Аудио-петля: читает PCM, кодирует AAC, дренирует в кольцо или мюксер.
	 * Переключение RING→FLUSH→LIVE — в этом же потоке, атомарно.
	 */
	private void audioMainLoop() {
		final AudioRecord rec = mAudRec;
		final int ch = mAudChannels;
		final int chunkSamples = AUDIO_SR * ch / 50; // 20 мс
		short[] buf = new short[chunkSamples];
		// Абсолютный старт в мкс — тот же CLOCK_MONOTONIC, что у видео-сенсора
		final long startUs = System.nanoTime() / 1000L;
		long totalFrames = 0L;

		rec.startRecording();
		while (mAudRunning) {
			int r = rec.read(buf, 0, chunkSamples);
			if (r <= 0) continue;

			// ── gain / soft-clip ──────────────────────────────────────────────
			final float g = mGain; final boolean sc = mSoftClip;
			long sumSq = 0;
			for (int i = 0; i < r; i++) {
				float s = buf[i] * g;
				if (sc) {
					final float T = 32768f * 0.7f, knee = 32768f - T;
					float ab = Math.abs(s);
					if (ab > T) s = Math.signum(s) * (T + knee * (float)Math.tanh((ab-T)/knee));
				}
				if (s > 32767f) s = 32767f; else if (s < -32768f) s = -32768f;
				buf[i] = (short) s; sumSq += (long) buf[i] * buf[i];
			}
			float peakAmp = 0f;
			for (int i = 0; i < r; i++) { float a = Math.abs(buf[i]) / 32768f; if (a > peakAmp) peakAmp = a; }
			mVu.setPeak(peakAmp);
			mVu.setLevel((float) Math.sqrt((double) sumSq / r) / 32768f);
			if (mOscilloscope != null) mOscilloscope.pushSamples(buf, r, ch);
			if (mEnvelope     != null) mEnvelope.pushSamples(buf, r, ch);
			// Спектр-анализатор отключаем при EIS — освобождаем CPU для видеопайплайна
			if (mSpectrum != null && !mEisEnabled) mSpectrum.pushSamples(buf, r, ch);

			// ── WAV параллельная запись сырого PCM ────────────────────────
			if (mRecording && mWavFos != null) writeWavPcm(buf, r);

			// ── кодируем PCM→AAC ──────────────────────────────────────────────
			MediaCodec enc = mAudEnc;
			if (enc == null) continue;
			// PTS: абсолютный System.nanoTime (мкс) — тот же домен, что у видео
			long pts = startUs + totalFrames * 1_000_000L / AUDIO_SR;
			totalFrames += r / ch;
			int idx = enc.dequeueInputBuffer(5_000);
			if (idx >= 0) {
				ByteBuffer bb = enc.getInputBuffer(idx);
				bb.clear();
				for (int i = 0; i < r; i++) { bb.put((byte)(buf[i]&0xFF)); bb.put((byte)(buf[i]>>8&0xFF)); }
				enc.queueInputBuffer(idx, 0, r * 2, pts, 0);
			}
			drainAudioEncoder(enc);
		}
		mVu.setLevel(0f);
		try { rec.stop(); } catch (Exception ignored) {}
	}

	/**
	 * Дренирует аудио-энкодер. Переключение RING→FLUSH→LIVE — здесь, атомарно.
	 */
	private void drainAudioEncoder(MediaCodec enc) {
		MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
		while (true) {
			int out = enc.dequeueOutputBuffer(info, 0);
			if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
				synchronized(mAudRingLock) { mAudOutFmt = enc.getOutputFormat(); }
				continue;
			}
			if (out < 0) break;
			try {
				boolean cfg = (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0;
				if (cfg || info.size <= 0) continue;
				ByteBuffer data = enc.getOutputBuffer(out);
				int mode = mAudWriteMode;

				if (mode == 0) {
					// RING
					EncodedFrame f = new EncodedFrame(data, info);
					synchronized(mAudRingLock) {
						mAudRing.addLast(f);
						while (mAudRing.size() > 1) {
							long span = mAudRing.peekLast().pts - mAudRing.peekFirst().pts;
							if (span <= (long) mPreBufSecs * 1_200_000L) break;
							mAudRing.removeFirst();
						}
					}
				} else if (mode == 1) {
					// FLUSH: сбрасываем кольцо начиная с первого аудио-фрейма >= mMuxBasePts
					synchronized(mAudRingLock) {
						boolean started = false;
						for (EncodedFrame rf : mAudRing) {
							if (!started && rf.pts < mMuxBasePts) continue;
							started = true;
							ByteBuffer rb = ByteBuffer.wrap(rf.data);
							MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
							bi.set(0, rf.data.length, rf.pts - mMuxBasePts, rf.flags);
							synchronized(mMuxLock) { if (mMuxReady) mMuxer.writeSampleData(mAudTrack, rb, bi); }
						}
						mAudRing.clear();
					}
					// Текущий аудио-пакет
					MediaCodec.BufferInfo n = new MediaCodec.BufferInfo();
					n.set(info.offset, info.size, info.presentationTimeUs - mMuxBasePts, info.flags);
					synchronized(mMuxLock) { if (mMuxReady) mMuxer.writeSampleData(mAudTrack, data, n); }
					mAudWriteMode = 2; // LIVE
				} else {
					// LIVE
					MediaCodec.BufferInfo n = new MediaCodec.BufferInfo();
					n.set(info.offset, info.size, info.presentationTimeUs - mMuxBasePts, info.flags);
					synchronized(mMuxLock) { if (mMuxReady) mMuxer.writeSampleData(mAudTrack, data, n); }
				}
			} finally { enc.releaseOutputBuffer(out, false); }
			if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
		}
	}

	// =========================================================================
	// REC: doStart / doStop / finalizeMuxer
	// =========================================================================

	/**
	 * doStart():
	 *  1. Вычисляем mMuxBasePts = PTS первого I-frame в видео-кольце.
	 *     Аудио-кольцо совпадает по clock → синхронизировано автоматически.
	 *  2. Создаём мюксер и добавляем треки.
	 *  3. Устанавливаем mVidWriteMode=FLUSH, mAudWriteMode=FLUSH.
	 *  4. Каждый поток сам (атомарно!) сбрасывает кольцо и продолжает LIVE.
	 *  Нет снимков, нет гонок, нет разрывов.
	 */
	@SuppressLint("MissingPermission")
	private void doStart() {
		try {
			// Ждём форматов от энкодеров (максимум 2 с)
			for (int wait = 0; wait < 40 && (mVidOutFmt == null || mAudOutFmt == null); wait++) {
				Thread.sleep(50);
			}
			if (mVidOutFmt == null || mAudOutFmt == null) {
				runOnUiThread(() -> { mBtn.setEnabled(true); status("Encoder not ready — retry"); });
				return;
			}

			// ── Вычисляем mMuxBasePts по первому I-frame в видео-кольце ───────
			long basePts;
			if (mEisEnabled) {
				// EIS-видео стартует с PTS=0 и растёт на 1000000/FPS.
				// Аудио пишется как (absAudioPts - mMuxBasePts).
				// Ставим basePts = текущее время → аудио тоже стартует от ~0.
				basePts = System.nanoTime() / 1000L;
			} else {
				synchronized(mVidRingLock) {
					if (mPreBufferEnabled) {
						basePts = Long.MAX_VALUE;
						for (EncodedFrame f : mVidRing) {
							if (f.isKey()) { basePts = f.pts; break; }
						}
						if (basePts == Long.MAX_VALUE) basePts = 0;
					} else {
						basePts = System.nanoTime() / 1000L;
					}
				}
			}
			mMuxBasePts = basePts;

			// ── Создаём MediaStore-запись ──────────────────────────────────────
			String displayPath;
			if (Build.VERSION.SDK_INT >= 29) {
				ContentValues cv = new ContentValues();
				cv.put(MediaStore.Video.Media.DISPLAY_NAME, "VID_" + System.currentTimeMillis() + ".mp4");
				cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
				cv.put(MediaStore.Video.Media.RELATIVE_PATH, "DCIM/CaMic");
				cv.put(MediaStore.Video.Media.IS_PENDING, 1);
				mPendingUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
				mPfd = getContentResolver().openFileDescriptor(mPendingUri, "rw");
				mMuxer = new MediaMuxer(mPfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
				displayPath = "DCIM/CaMic";
			} else {
				@SuppressWarnings("deprecation")
				File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "CaMic");
				dir.mkdirs();
				File f = new File(dir, "VID_" + System.currentTimeMillis() + ".mp4");
				mMuxer = new MediaMuxer(f.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
				displayPath = f.getAbsolutePath();
			}
			@SuppressWarnings("deprecation")
			int rot = getWindowManager().getDefaultDisplay().getRotation() * 90;
			int rotAngleForHint = (mSensorOrientation - rot + 360) % 360;
			mMuxer.setOrientationHint(rotAngleForHint);
			mEisRotHint = rotAngleForHint;

			// ── EIS encoder: запускаем и ждём формат (до 2 с) ───────────────────
			if (mEisEnabled) {
				startEisEncoder();
				for (int w = 0; w < 40 && mEisVidOutFmt == null; w++)
					Thread.sleep(50);
				if (mEisVidOutFmt != null)
					eisLog("doStart: format received OK");
				else
					eisLog("doStart: FORMAT TIMEOUT — no video track");
			}

			// ── Добавляем треки, стартуем мюксер ──────────────────────────────
			synchronized(mMuxLock) {
				if (mEisEnabled && mEisVidOutFmt != null) {
					mEisVidTrack = mMuxer.addTrack(mEisVidOutFmt);
					mEisEncReady = true;
				} else {
					mVidTrack = mMuxer.addTrack(mVidOutFmt);
				}
				mAudTrack = mMuxer.addTrack(mAudOutFmt);
				mMuxer.start();
				mMuxReady = true;
			}

			// ── WAV параллельная запись ───────────────────────────────────────
			startWavWriter(mAudChannels);

			// ── Переводим потоки в режим FLUSH → они сами сбросят кольца ──────
			mRecording = true;
			if (mPreBufferEnabled) {
				if (!mEisEnabled) mVidWriteMode = 1; // FLUSH (EIS пишет напрямую)
				mAudWriteMode = 1; // FLUSH
			} else {
				if (!mEisEnabled) mVidWriteMode = 2; // LIVE сразу
				mAudWriteMode = 2;
			}

			final String fp = displayPath;
			runOnUiThread(() -> {
				mBtn.setText("⏹ STOP"); mBtn.setBackground(mBtnBgRec); mBtn.setEnabled(true);
				mBtnPause.setVisibility(View.VISIBLE);
				mBtnPause.setText("⏸"); mBtnPause.setBackground(mBtnBgPause);
				mPaused = false;
				status("● REC  →  " + fp);
			});
		} catch (Exception e) {
			mRecording = false; mVidWriteMode = 0; mAudWriteMode = 0;
			finalizeMuxer();
			runOnUiThread(() -> {
				mBtn.setText("⏺ REC"); mBtn.setBackground(mBtnBgIdle); mBtn.setEnabled(true);
				mBtnPause.setVisibility(View.GONE);
				status("Error: " + e.getMessage());
			});
		}
	}

	private void doStop() {
		try { Thread.sleep(200); } catch (Exception ignored) {}
		mVidWriteMode = 0; mAudWriteMode = 0;
		mEisEncReady  = false;
		if (mEisEnabled) eisLog("doStop: stopping encoder");
		stopEisEncoder();
		finalizeMuxer();
		finalizeWavWriter();
	}

	private void finalizeMuxer() {
		synchronized(mMuxLock) {
			try { if (mMuxer != null) { if (mMuxReady) mMuxer.stop(); mMuxer.release(); } }
			catch (Exception ignored) {}
			mMuxer = null; mMuxReady = false;
			mVidTrack = -1; mAudTrack = -1;
			mEisVidTrack = -1; mEisVidOutFmt = null;
		}
		try { if (mPfd != null) { mPfd.close(); mPfd = null; } } catch (Exception ignored) {}
		if (Build.VERSION.SDK_INT >= 29 && mPendingUri != null) {
			ContentValues cv = new ContentValues();
			cv.put(MediaStore.Video.Media.IS_PENDING, 0);
			getContentResolver().update(mPendingUri, cv, null, null);
			mPendingUri = null;
		}
		runOnUiThread(() -> {
			mBtn.setText("⏺ REC"); mBtn.setBackground(mBtnBgIdle); mBtn.setEnabled(true);
			mBtnPause.setVisibility(View.GONE);
			mPaused = false;
			status("Saved");
		});
	}


	private void status(String s) {
		runOnUiThread(() -> mTvStatus.setText(s));
	}
	
	// =========================================================================
	// Аудио-источники
	// =========================================================================
	
	private void buildAudioSources() {
		List<AudioSrcItem> list = new ArrayList<>();
		if (Build.VERSION.SDK_INT >= 23) {
			AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
			AudioDeviceInfo[] devs = am.getDevices(AudioManager.GET_DEVICES_INPUTS);
			boolean hasBuiltin = false;
			for (AudioDeviceInfo d : devs) {
				int t = d.getType();
				if (t == AudioDeviceInfo.TYPE_BUILTIN_MIC) {
					if (hasBuiltin)
					continue;
					hasBuiltin = true;
					list.add(new AudioSrcItem("Built-in mic", MediaRecorder.AudioSource.MIC, d));
					if (Build.VERSION.SDK_INT >= 24)
					list.add(new AudioSrcItem("Built-in mic (raw)", MediaRecorder.AudioSource.UNPROCESSED, d));
					} else if (t == AudioDeviceInfo.TYPE_USB_DEVICE || t == AudioDeviceInfo.TYPE_USB_HEADSET) {
					CharSequence pn = d.getProductName();
					list.add(new AudioSrcItem("USB: " + (pn != null && pn.length() > 0 ? pn : "audio"),
					MediaRecorder.AudioSource.MIC, d));
					} else if (t == AudioDeviceInfo.TYPE_WIRED_HEADSET) {
					list.add(new AudioSrcItem("Wired headset", MediaRecorder.AudioSource.MIC, d));
					} else if (t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
					list.add(new AudioSrcItem("Bluetooth mic", MediaRecorder.AudioSource.MIC, d));
				}
			}
		}
		if (list.isEmpty()) {
			list.add(new AudioSrcItem("Default", MediaRecorder.AudioSource.DEFAULT, null));
			list.add(new AudioSrcItem("Microphone", MediaRecorder.AudioSource.MIC, null));
			list.add(new AudioSrcItem("Camcorder", MediaRecorder.AudioSource.CAMCORDER, null));
			list.add(new AudioSrcItem("Communication", MediaRecorder.AudioSource.VOICE_COMMUNICATION, null));
			if (Build.VERSION.SDK_INT >= 24)
			list.add(new AudioSrcItem("Unprocessed (raw)", MediaRecorder.AudioSource.UNPROCESSED, null));
		}
		runOnUiThread(() -> {
			mSrcList.clear();
			mSrcList.addAll(list);
			List<String> names = new ArrayList<>();
			for (AudioSrcItem item : mSrcList)
			names.add(item.name);
			@SuppressWarnings("unchecked")
			ArrayAdapter<String> ad2 = (ArrayAdapter<String>) mSpinner.getAdapter();
			ad2.clear();
			ad2.addAll(names);
			ad2.notifyDataSetChanged();
			
			int defaultIdx = 0;
			for (int i = 0; i < mSrcList.size(); i++) {
				AudioSrcItem item = mSrcList.get(i);
				if (item.device != null && Build.VERSION.SDK_INT >= 23) {
					int t = item.device.getType();
					if (t == AudioDeviceInfo.TYPE_USB_DEVICE || t == AudioDeviceInfo.TYPE_USB_HEADSET) {
						defaultIdx = i;
						break;
					}
				}
			}
			if (defaultIdx == 0) {
				for (int i = 0; i < mSrcList.size(); i++) {
					if (mSrcList.get(i).audioSource == MediaRecorder.AudioSource.UNPROCESSED) {
						defaultIdx = i;
						break;
					}
				}
			}
			mSpinner.setSelection(defaultIdx);
			if (!mRecording) {
				stopAudio();
				startMonitor();
			}
		});
	}
	
	// =========================================================================
	// Вспомогательные классы
	// =========================================================================
	
	private static class AudioSrcItem {
		final String name;
		final int audioSource;
		final AudioDeviceInfo device;
		
		AudioSrcItem(String n, int s, AudioDeviceInfo d) {
			name = n;
			audioSource = s;
			device = d;
		}
	}
	
	static class VerticalSeekBar extends View {
		private int mMax = 100;
		private int mProgress = 0;
		
		private final Paint mTrackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mThumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mRidgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		
		private SeekBar.OnSeekBarChangeListener mListener;
		
		VerticalSeekBar(Context c) {
			super(c);
			mTrackPaint.setColor(0x44FFFFFF);
			mFillPaint.setColor(0xFFDDCC00);
			mThumbPaint.setColor(0xFFEEEEEE);
			mRidgePaint.setColor(0xFF888866);
			mRidgePaint.setStyle(Paint.Style.STROKE);
			mRidgePaint.setStrokeWidth(1.2f * c.getResources().getDisplayMetrics().density);
			setClickable(true);
		}
		
		void setMax(int max) { mMax = max; invalidate(); }
		void setProgress(int p) { mProgress = Math.max(0, Math.min(mMax, p)); invalidate(); }
		int getMax() { return mMax; }
		int getProgress() { return mProgress; }
		void setOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener l) { mListener = l; }

		// Высота ручки микшера в px
		private float faderH(float w) { return Math.round(w * 0.7f) + dp(20); }

		private int dp(int x) {
			return Math.round(x * getResources().getDisplayMetrics().density);
		}
		
		@Override
		protected void onDraw(Canvas canvas) {
			final float w = getWidth(), h = getHeight();
			final float trackW = w * 0.3f;
			final float cx = w / 2f;
			final float trkX1 = cx - trackW / 2f;
			final float trkX2 = cx + trackW / 2f;
			final float halfFader = faderH(w) / 2f;
			final float padV = halfFader + 2f;
			final float trkT = padV;
			final float trkB = h - padV;
			final float trkH = trkB - trkT;

			float frac = mMax > 0 ? (float) mProgress / mMax : 0f;
			float thumbY = trkB - frac * trkH;

			// Трек
			canvas.drawRoundRect(new RectF(trkX1, trkT, trkX2, trkB),
				trackW / 2f, trackW / 2f, mTrackPaint);
			// Заполненная часть
			canvas.drawRoundRect(new RectF(trkX1, thumbY, trkX2, trkB),
				trackW / 2f, trackW / 2f, mFillPaint);
			// Метка 0 dB
			Paint z = new Paint(Paint.ANTI_ALIAS_FLAG);
			z.setColor(0x88FFFFFF); z.setStrokeWidth(1.5f);
			canvas.drawLine(trkX1 - 3f, trkB - 0.5f * trkH, trkX2 + 3f, trkB - 0.5f * trkH, z);

			// ── Ручка (fader cap) — широкий прямоугольник во всю ширину ──────
			float fH = faderH(w);
			float fW = w - 2f;
			RectF fader = new RectF(1f, thumbY - fH/2f, 1f + fW, thumbY + fH/2f);
			// Тень
			Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
			shadow.setColor(0x66000000);
			shadow.setStyle(Paint.Style.FILL);
			canvas.drawRoundRect(new RectF(fader.left+2, fader.top+3, fader.right+2, fader.bottom+3),
				dp(4), dp(4), shadow);
			// Тело ручки
			canvas.drawRoundRect(fader, dp(4), dp(4), mThumbPaint);
			// Горизонтальные риски (3 штуки по центру)
			float rInset = fW * 0.18f;
			for (int ri = -1; ri <= 1; ri++) {
				float ry = thumbY + ri * dp(4);
				canvas.drawLine(1f + rInset, ry, 1f + fW - rInset, ry, mRidgePaint);
			}
			// Центральная риска чуть длиннее и ярче
			Paint cLine = new Paint(Paint.ANTI_ALIAS_FLAG);
			cLine.setColor(0xFFDDCC00); cLine.setStrokeWidth(1.5f);
			canvas.drawLine(1f + rInset * 0.6f, thumbY, 1f + fW - rInset * 0.6f, thumbY, cLine);
		}
		
		@Override
		public boolean onTouchEvent(MotionEvent e) {
			if (!isEnabled()) return false;
			final float h = getHeight(), w = getWidth();
			final float halfFader = faderH(w) / 2f;
			final float padV = halfFader + 2f;
			final float trkT = padV;
			final float trkB = h - padV;
			final float trkH = trkB - trkT;
			
			switch (e.getAction()) {
				case MotionEvent.ACTION_DOWN:
				if (mListener != null) mListener.onStartTrackingTouch(null);
				// fall through
				case MotionEvent.ACTION_MOVE: {
					float frac = 1f - (e.getY() - trkT) / trkH;
					int p = Math.max(0, Math.min(mMax, Math.round(frac * mMax)));
					mProgress = p;
					invalidate();
					if (mListener != null) mListener.onProgressChanged(null, p, true);
					return true;
				}
				case MotionEvent.ACTION_UP:
				case MotionEvent.ACTION_CANCEL:
				if (mListener != null) mListener.onStopTrackingTouch(null);
				return true;
			}
			return false;
		}
	}
	
	// ─── Вертикальный VU-метр dBFS ───────────────────────────────────────────
	// Сегменты снизу вверх. Пик-маркер — горизонтальная черта с hold 1.8s.

	static class VuMeterView extends View {
		private static final int N = 30;
		private static final float MIN_DB = -60f;
		private static final long PEAK_HOLD_MS = 1800;

		private final Paint mSegPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mPeakPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mDbLblPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final RectF mRect       = new RectF();
		private float mLevelDb  = MIN_DB;
		private float mPeakDb   = MIN_DB;
		private long  mPeakHoldUntil = 0;

		VuMeterView(Context c) {
			super(c);
			mPeakPaint.setColor(0xFFFFFFFF);
			float vuDensity = c.getResources().getDisplayMetrics().density;
			mPeakPaint.setStrokeWidth(4f * vuDensity);
			mPeakPaint.setStyle(Paint.Style.STROKE);
			float density = c.getResources().getDisplayMetrics().density;
			mDbLblPaint.setTextSize(5.5f * density);
			mDbLblPaint.setTextAlign(Paint.Align.RIGHT);
			mDbLblPaint.setAntiAlias(true);
		}

		void setLevel(float rms) {
			mLevelDb = rms > 1e-6f ? Math.max(MIN_DB, (float)(20.0 * Math.log10(rms))) : MIN_DB;
			postInvalidate();
		}

		void setPeak(float peak) {
			float db = peak > 1e-6f ? Math.max(MIN_DB, (float)(20.0 * Math.log10(peak))) : MIN_DB;
			if (db >= mPeakDb || System.currentTimeMillis() > mPeakHoldUntil) {
				mPeakDb = db;
				mPeakHoldUntil = System.currentTimeMillis() + PEAK_HOLD_MS;
			}
		}

		@Override
		protected void onDraw(Canvas canvas) {
			final float w = getWidth(), h = getHeight();
			final float segH = (h - N - 1f) / N;
			final float segW = w - 2f;

			for (int i = 0; i < N; i++) {
				float segDb = MIN_DB + (float) i / N * (-MIN_DB);
				boolean lit = mLevelDb >= segDb;
				int color;
				if (!lit)             color = 0xFF181818;
				else if (segDb < -12f) color = 0xFF00CC55;
				else if (segDb <  -6f) color = 0xFFFFBB00;
				else                   color = 0xFFFF2200;
				mSegPaint.setColor(color);
				float y = h - 1f - i * (segH + 1f) - segH;
				mRect.set(1f, y, 1f + segW, y + segH);
				canvas.drawRoundRect(mRect, 2f, 2f, mSegPaint);
			}

			// Пик-маркер
			if (mPeakDb > MIN_DB) {
				float frac = (mPeakDb - MIN_DB) / (-MIN_DB);
				float py = h - 1f - frac * (h - 2f);
				long now = System.currentTimeMillis();
				int peakColor;
				if      (mPeakDb >= -3f)  peakColor = 0xFFFF2200;
				else if (mPeakDb >= -12f) peakColor = 0xFFFFBB00;
				else                      peakColor = 0xFF00FF88;
				boolean fading = now > mPeakHoldUntil - 400;
				if (!fading || (now / 150) % 2 == 0) {
					mPeakPaint.setColor(peakColor);
					canvas.drawLine(0, py, w, py, mPeakPaint);
				}
			}

			// ── dB-метки поверх индикатора ────────────────────────────────────
			float[] dbMarks  = { 0f, -6f, -12f, -24f, -48f, -60f };
			String[] dbStrs  = { "0", "-6", "-12", "-24", "-48", "-60" };
			float lblAscent = -mDbLblPaint.ascent();
			for (int di = 0; di < dbMarks.length; di++) {
				float frac = (dbMarks[di] - MIN_DB) / (-MIN_DB);
				float ly   = h - 1f - frac * (h - 2f);
				// цвет совпадает с цветом сегмента
				if      (dbMarks[di] >= -6f)  mDbLblPaint.setColor(0xFFFF6644);
				else if (dbMarks[di] >= -12f) mDbLblPaint.setColor(0xFFFFDD44);
				else                          mDbLblPaint.setColor(0xCCBBFFCC);
				mDbLblPaint.setAlpha(200);
				// рисуем справа, сдвинув вверх на половину высоты шрифта
				canvas.drawText(dbStrs[di], w - 1f, ly + lblAscent * 0.5f, mDbLblPaint);
			}
		}
	}
	
	// ─── Рычаг зума ──────────────────────────────────────────────────────────
	
	static class ZoomLeverView extends View {
		interface Listener {
			void onLever(float pos);
		}
		
		private Listener mListener;
		private volatile float mPos = 0f;
		private boolean mTracking = false;
		private float trkT, trkB, trkH, trkW, mid, cx;
		
		private final Paint mTrackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mThumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mMarkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		
		ZoomLeverView(Context c) {
			super(c);
			mTrackPaint.setColor(0x55FFFFFF);
			mThumbPaint.setColor(0xFFFFFFFF);
			mMarkPaint.setColor(0xAAFFFFFF);
			mMarkPaint.setStyle(Paint.Style.STROKE);
			mMarkPaint.setStrokeWidth(1.5f * c.getResources().getDisplayMetrics().density);
			mTextPaint.setColor(0xCCFFFFFF);
			mTextPaint.setTextAlign(Paint.Align.CENTER);
			mTextPaint.setTextSize(11 * c.getResources().getDisplayMetrics().density);
			setBackgroundColor(0x44000000);
		}
		
		void setListener(Listener l) {
			mListener = l;
		}
		
		private void recalc() {
			float w = getWidth(), h = getHeight();
			float lblH = mTextPaint.getTextSize() + dp(4);
			trkT = lblH;
			trkB = h - lblH;
			trkH = trkB - trkT;
			trkW = dp(16);
			mid = (trkT + trkB) / 2f;
			cx = w / 2f;
		}
		
		@Override
		protected void onDraw(Canvas canvas) {
			recalc();
			float h = getHeight();
			RectF track = new RectF(cx - trkW / 2f, trkT, cx + trkW / 2f, trkB);
			canvas.drawRoundRect(track, dp(5), dp(5), mTrackPaint);
			canvas.drawLine(cx - trkW / 2f - dp(6), mid, cx + trkW / 2f + dp(6), mid, mMarkPaint);
			float thumbCY = mid - mPos * trkH / 2f;
			float thumbH = dp(28), thumbW = trkW + dp(12);
			mThumbPaint.setAlpha((int) (160 + 90 * Math.abs(mPos)));
			canvas.drawRoundRect(
			new RectF(cx - thumbW / 2f, thumbCY - thumbH / 2f, cx + thumbW / 2f, thumbCY + thumbH / 2f), dp(6),
			dp(6), mThumbPaint);
			Paint.FontMetrics fm = mTextPaint.getFontMetrics();
			float pad = mTextPaint.getTextSize() + dp(2);
			canvas.drawText("T+", cx, pad / 2f - (fm.ascent + fm.descent) / 2f, mTextPaint);
			canvas.drawText("W−", cx, h - pad / 2f - fm.ascent, mTextPaint);
		}
		
		@Override
		public boolean onTouchEvent(MotionEvent e) {
			recalc();
			switch (e.getAction()) {
				case MotionEvent.ACTION_DOWN:
				case MotionEvent.ACTION_MOVE:
				removeCallbacks(mSpring);
				mTracking = true;
				mPos = Math.max(-1f, Math.min(1f, (mid - e.getY()) / (trkH / 2f)));
				if (mListener != null)
				mListener.onLever(mPos);
				invalidate();
				return true;
				case MotionEvent.ACTION_UP:
				case MotionEvent.ACTION_CANCEL:
				mTracking = false;
				post(mSpring);
				return true;
			}
			return super.onTouchEvent(e);
		}
		
		private final Runnable mSpring = new Runnable() {
			@Override
			public void run() {
				if (mTracking)
				return;
				mPos *= 0.75f;
				if (mListener != null)
				mListener.onLever(mPos);
				invalidate();
				if (Math.abs(mPos) > 0.01f)
				postDelayed(this, 16);
				else {
					mPos = 0f;
					if (mListener != null)
					mListener.onLever(0f);
					invalidate();
				}
			}
		};
		
		private int dp(int x) {
			return Math.round(x * getResources().getDisplayMetrics().density);
		}
	}
	
	// ─── Focus Assist — зумированное окно в центре экрана ───────────────────
	// Захватывает центральную область превью через PixelCopy и рисует её
	// с увеличением x4. Обновляется каждые ~100 мс.
	// Поверх — сетка Петцваля и рамка.
	
	class FocusAssistView extends View implements Runnable {
		private Bitmap mBmp;
		private final Paint mBmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
		private final Paint mBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mLabelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private static final int ZOOM = 4;
		private static final int SAMPLE_SIZE = 120; // px стороны захватываемого квадрата
		private volatile boolean mRunning;
		
		FocusAssistView(Context c) {
			super(c);
			mBorderPaint.setColor(0xFFDDCC00);
			mBorderPaint.setStyle(Paint.Style.STROKE);
			mBorderPaint.setStrokeWidth(2f);
			mGridPaint.setColor(0x55FFFFFF);
			mGridPaint.setStyle(Paint.Style.STROKE);
			mGridPaint.setStrokeWidth(0.8f);
			mLabelPaint.setColor(0xFFDDCC00);
			mLabelPaint.setTextAlign(Paint.Align.CENTER);
			mLabelPaint.setTextSize(10 * getResources().getDisplayMetrics().density);
			mLabelPaint.setAntiAlias(true);
			setBackgroundColor(0x00000000);
		}
		
		@Override
		protected void onAttachedToWindow() {
			super.onAttachedToWindow();
			mRunning = true;
			postDelayed(this, 100);
		}
		
		@Override
		protected void onDetachedFromWindow() {
			super.onDetachedFromWindow();
			mRunning = false;
			removeCallbacks(this);
		}
		
		@Override
		public void run() {
			if (!mRunning || getVisibility() != View.VISIBLE) {
				if (mRunning) postDelayed(this, 200);
				return;
			}
			capture();
			postDelayed(this, 100);
		}
		
		private void capture() {
			if (mSv == null || !mSurfaceReady) return;
			if (android.os.Build.VERSION.SDK_INT < 26) {
				// PixelCopy недоступен — рисуем заглушку
				invalidate();
				return;
			}
			try {
				int svW = mSv.getWidth(), svH = mSv.getHeight();
				if (svW <= 0 || svH <= 0) return;
				
				// Центральная область SAMPLE_SIZE × SAMPLE_SIZE
				int cx = svW / 2, cy = svH / 2, half = SAMPLE_SIZE / 2;
				int l = Math.max(0, cx - half), t = Math.max(0, cy - half);
				int r = Math.min(svW, l + SAMPLE_SIZE), b = Math.min(svH, t + SAMPLE_SIZE);
				android.graphics.Rect src = new android.graphics.Rect(l, t, r, b);
				
				Bitmap dst = Bitmap.createBitmap(r - l, b - t, Bitmap.Config.ARGB_8888);
				android.view.PixelCopy.request(mSv, src, dst, result -> {
					if (result == android.view.PixelCopy.SUCCESS) {
						mBmp = dst;
						postInvalidate();
					}
				}, new Handler(android.os.Looper.getMainLooper()));
			} catch (Exception ignored) {}
		}
		
		@Override
		protected void onDraw(Canvas canvas) {
			final float w = getWidth(), h = getHeight();
			
			// Фон — чёрный полупрозрачный
			canvas.drawARGB(200, 0, 0, 0);
			
			if (mBmp != null && !mBmp.isRecycled()) {
				// Рисуем захваченный фрагмент, растянутый на весь квадрат
				android.graphics.RectF dst = new android.graphics.RectF(0, 0, w, h);
				canvas.drawBitmap(mBmp, null, dst, mBmpPaint);
				} else {
				// Заглушка когда PixelCopy ещё не отработал
				Paint p = new Paint();
				p.setColor(0xFF333333);
				canvas.drawRect(0, 0, w, h, p);
			}
			
			// Сетка — тонкая перекрёстная линия (центральная)
			canvas.drawLine(w / 2f, 0, w / 2f, h, mGridPaint);
			canvas.drawLine(0, h / 2f, w, h / 2f, mGridPaint);
			// Третьи (по правило третей)
			canvas.drawLine(w / 3f, 0, w / 3f, h, mGridPaint);
			canvas.drawLine(2 * w / 3f, 0, 2 * w / 3f, h, mGridPaint);
			canvas.drawLine(0, h / 3f, w, h / 3f, mGridPaint);
			canvas.drawLine(0, 2 * h / 3f, w, 2 * h / 3f, mGridPaint);
			
			// Рамка
			canvas.drawRect(1f, 1f, w - 1f, h - 1f, mBorderPaint);
			
			// Уголки (более жирные акценты)
			float corner = w * 0.12f;
			mBorderPaint.setStrokeWidth(3f);
			canvas.drawLine(1f, 1f, corner, 1f, mBorderPaint);
			canvas.drawLine(1f, 1f, 1f, corner, mBorderPaint);
			canvas.drawLine(w - corner, 1f, w - 1f, 1f, mBorderPaint);
			canvas.drawLine(w - 1f, 1f, w - 1f, corner, mBorderPaint);
			canvas.drawLine(1f, h - corner, 1f, h - 1f, mBorderPaint);
			canvas.drawLine(1f, h - 1f, corner, h - 1f, mBorderPaint);
			canvas.drawLine(w - 1f, h - corner, w - 1f, h - 1f, mBorderPaint);
			canvas.drawLine(w - corner, h - 1f, w - 1f, h - 1f, mBorderPaint);
			mBorderPaint.setStrokeWidth(2f);
			
			// Подпись
			canvas.drawText("FOCUS ×" + ZOOM, w / 2f, h - 4f, mLabelPaint);
		}
	}
	
	// ─── Барабан фокуса (как кольцо на настоящей камере) ────────────────────
	// Свайп вниз = фокус вдаль (∞), свайп вверх = макро.
	// Визуально: риски на цилиндре с перспективным сжатием.
	
	static class FocusDrumView extends View {
		interface OnFocusChangeListener {
			void onFocusChanged(float value); // 0=∞, 1=macro
		}
		
		/** Коллбэк начала/остановки прокрутки барабана */
		interface OnDrumScrollListener {
			void onScrollStart();
			void onScrollStop();
		}
		
		private OnFocusChangeListener mListener;
		private OnDrumScrollListener mScrollListener;
		private float mValue = 0f; // 0..1
		private float mLastY;
		private boolean mDragging;
		
		// Визуальный «угол» барабана — непрерывный для анимации рисок
		private float mAngle = 0f;
		private static final float FULL_RANGE_PX_PER_UNIT = 800f;
		
		private final Paint mDrumPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mRiskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mCenterLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		
		FocusDrumView(Context c) {
			super(c);
			float density = c.getResources().getDisplayMetrics().density;
			mDrumPaint.setColor(0xFF2A2A2A);
			mRiskPaint.setStrokeWidth(1.5f * density);
			mRiskPaint.setStyle(Paint.Style.STROKE);
			mShadowPaint.setStyle(Paint.Style.FILL);
			mCenterLinePaint.setColor(0xFFDDCC00);
			mCenterLinePaint.setStrokeWidth(2f * density);
			mCenterLinePaint.setStyle(Paint.Style.STROKE);
		}
		
		void setOnFocusChangeListener(OnFocusChangeListener l) {
			mListener = l;
		}
		
		void setOnDrumScrollListener(OnDrumScrollListener l) {
			mScrollListener = l;
		}
		
		@Override
		protected void onDraw(Canvas canvas) {
			final float w = getWidth(), h = getHeight();
			final float cx = w / 2f;
			final float drumW = w * 0.72f;
			final float drumLeft = cx - drumW / 2f;
			final float drumRight = cx + drumW / 2f;
			
			// Фон барабана
			RectF drumRect = new RectF(drumLeft, 0, drumRight, h);
			mDrumPaint.setColor(0xFF222222);
			canvas.drawRoundRect(drumRect, drumW * 0.12f, drumW * 0.12f, mDrumPaint);
			
			// Риски барабана с перспективным сжатием
			final float riskStep = h * 0.07f;
			float offset = mAngle % riskStep;
			if (offset < 0) offset += riskStep;
			
			final int totalRisks = (int) (h / riskStep) + 2;
			for (int i = -1; i <= totalRisks; i++) {
				float ry = offset + i * riskStep;
				if (ry < 0 || ry > h) continue;
				
				float distFromCenter = Math.abs(ry - h / 2f) / (h / 2f);
				float squeeze = 1f - 0.55f * distFromCenter * distFromCenter;
				float riskLen = drumW * 0.8f * squeeze;
				int alpha = (int) (200 * (1f - distFromCenter * 0.7f));
				
				boolean isMajor = (Math.abs(Math.round((ry - offset) / riskStep)) % 5 == 0);
				if (isMajor) { riskLen *= 1.25f; alpha = Math.min(255, alpha + 40); }
				
				mRiskPaint.setColor(0xFFFFFFFF);
				mRiskPaint.setAlpha(alpha);
				mRiskPaint.setStrokeWidth(isMajor ? 2f : 1.2f);
				canvas.drawLine(cx - riskLen / 2f, ry, cx + riskLen / 2f, ry, mRiskPaint);
			}
			
			// Градиентные тени сверху/снизу (имитация цилиндра)
			int[] colorsTop = { 0xCC000000, 0x00000000 };
			int[] colorsBot = { 0x00000000, 0xCC000000 };
			android.graphics.LinearGradient shadTop = new android.graphics.LinearGradient(
			0, 0, 0, h * 0.28f, colorsTop, null, android.graphics.Shader.TileMode.CLAMP);
			android.graphics.LinearGradient shadBot = new android.graphics.LinearGradient(
			0, h * 0.72f, 0, h, colorsBot, null, android.graphics.Shader.TileMode.CLAMP);
			mShadowPaint.setShader(shadTop);
			canvas.drawRoundRect(drumRect, drumW * 0.12f, drumW * 0.12f, mShadowPaint);
			mShadowPaint.setShader(shadBot);
			canvas.drawRoundRect(drumRect, drumW * 0.12f, drumW * 0.12f, mShadowPaint);
			mShadowPaint.setShader(null);
			
			// Центральная риска-указатель (жёлтая)
			canvas.drawLine(drumLeft - 4f, h / 2f, drumRight + 4f, h / 2f, mCenterLinePaint);
		}
		
		@Override
		public boolean onTouchEvent(MotionEvent e) {
			switch (e.getAction()) {
				case MotionEvent.ACTION_DOWN:
				mLastY = e.getY();
				mDragging = true;
				if (mScrollListener != null) mScrollListener.onScrollStart();
				return true;
				case MotionEvent.ACTION_MOVE: {
					if (!mDragging) return true;
					float dy = e.getY() - mLastY;
					mLastY = e.getY();
					// Свайп вниз → фокус на ∞ (value уменьшается)
					// Свайп вверх → макро (value увеличивается)
					mAngle += dy;
					float newVal = mValue - dy / FULL_RANGE_PX_PER_UNIT;
					newVal = Math.max(0f, Math.min(1f, newVal));
					// Фиксируем барабан у упора
					if (newVal == 0f && mValue == 0f) mAngle = Math.min(mAngle, 0f);
					if (newVal == 1f && mValue == 1f) mAngle = Math.max(mAngle, 0f);
					if (newVal != mValue) {
						mValue = newVal;
						if (mListener != null) mListener.onFocusChanged(mValue);
					}
					invalidate();
					return true;
				}
				case MotionEvent.ACTION_UP:
				case MotionEvent.ACTION_CANCEL:
				mDragging = false;
				if (mScrollListener != null) mScrollListener.onScrollStop();
				return true;
			}
			return false;
		}
	}

	// ─── Осциллограф с триггером ─────────────────────────────────────────────
	// Прозрачный фон, наложен поверх изображения камеры.
	// Триггер: фронт нарастания (rising edge) при пересечении порога.
	// Окно отображения — 2048 выборок (~46 мс при 44100 Гц).
	
	static class OscilloscopeView extends View {
		private static final int DISP_SAMPLES = 2048;
		private static final int BUF_SIZE = DISP_SAMPLES * 4; // кольцевой буфер
		
		private final float[] mRingBuf = new float[BUF_SIZE];
		private int mWritePos = 0;
		private final float[] mFrame = new float[DISP_SAMPLES];
		private volatile boolean mNewFrame = false;
		private final Object mLock = new Object();
		
		// Триггер
		private static final float TRIG_LEVEL = 0.05f; // нормализованный уровень
		private static final int TRIG_HYSTERESIS = 64; // выборок предыстории
		
		private final Paint mWavePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mGridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mLabelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		/** Цвет по амплитуде 0..1 — как сегменты VU-метра */
		static int levelColor(float amp) {
			if (amp >= 0.7f) return 0xFFFF2200;
			if (amp >= 0.3f) return 0xFFFFBB00;
			return 0xFF00CC55;
		}

		OscilloscopeView(Context c) {
			super(c);
			setBackgroundColor(0x00000000); // прозрачный
			mWavePaint.setStrokeWidth(1.8f * c.getResources().getDisplayMetrics().density);
			mWavePaint.setStyle(Paint.Style.STROKE);
			mWavePaint.setStrokeCap(Paint.Cap.ROUND);
			mGridPaint.setColor(0x33FFFFFF);
			mGridPaint.setStrokeWidth(0.8f);
			mGridPaint.setStyle(Paint.Style.STROKE);
			mLabelPaint.setColor(0xAAFFFFFF);
			mLabelPaint.setTextSize(9 * c.getResources().getDisplayMetrics().density);
			mLabelPaint.setAntiAlias(true);
		}
		
		/** Принимает буфер PCM-16, конвертирует в mono float и кладёт в кольцевой буфер */
		void pushSamples(short[] buf, int len, int channels) {
			synchronized (mLock) {
				for (int i = 0; i < len; i += channels) {
					float mono = buf[i] / 32768f;
					if (channels == 2 && i + 1 < len)
						mono = (mono + buf[i + 1] / 32768f) * 0.5f;
					mRingBuf[mWritePos] = mono;
					mWritePos = (mWritePos + 1) % BUF_SIZE;
				}
				// Поиск триггера: восходящий фронт >= TRIG_LEVEL
				// Ищем в последних BUF_SIZE выборках
				int trigPos = -1;
				int searchStart = (mWritePos - BUF_SIZE + BUF_SIZE) % BUF_SIZE;
				for (int k = TRIG_HYSTERESIS; k < BUF_SIZE - DISP_SAMPLES; k++) {
					int p = (searchStart + k) % BUF_SIZE;
					int pp = (p - 1 + BUF_SIZE) % BUF_SIZE;
					if (mRingBuf[pp] < TRIG_LEVEL && mRingBuf[p] >= TRIG_LEVEL) {
						trigPos = p;
						break;
					}
				}
				if (trigPos < 0) {
					// Триггер не найден — показываем последние DISP_SAMPLES
					trigPos = (mWritePos - DISP_SAMPLES + BUF_SIZE) % BUF_SIZE;
				}
				for (int k = 0; k < DISP_SAMPLES; k++) {
					mFrame[k] = mRingBuf[(trigPos + k) % BUF_SIZE];
				}
				mNewFrame = true;
			}
			postInvalidate();
		}
		
		@Override
		protected void onDraw(Canvas canvas) {
			final float w = getWidth(), h = getHeight();
			if (w == 0 || h == 0) return;

			// Полностью прозрачный фон — не рисуем ничего
			// canvas.drawARGB(90, 0, 0, 0);
			
			// Сетка
			for (int gx = 1; gx < 4; gx++)
				canvas.drawLine(w * gx / 4f, 0, w * gx / 4f, h, mGridPaint);
			for (int gy = 1; gy < 4; gy++)
				canvas.drawLine(0, h * gy / 4f, w, h * gy / 4f, mGridPaint);
			// Ось Y = 0
			Paint zeroPaint = new Paint(mGridPaint);
			zeroPaint.setColor(0x55FFFFFF);
			zeroPaint.setStrokeWidth(1.4f);
			canvas.drawLine(0, h / 2f, w, h / 2f, zeroPaint);
			
			// Линия уровня триггера
			Paint trigPaint = new Paint();
			trigPaint.setColor(0x88FFFF00);
			trigPaint.setStrokeWidth(1f);
			trigPaint.setStyle(Paint.Style.STROKE);
			trigPaint.setPathEffect(new android.graphics.DashPathEffect(new float[]{6f, 4f}, 0));
			float trigY = h / 2f - TRIG_LEVEL * h / 2f;
			canvas.drawLine(0, trigY, w, trigY, trigPaint);
			
			// Волна — цветные сегменты (зелёный→оранжевый→красный)
			float[] frame;
			synchronized (mLock) {
				frame = mFrame.clone();
			}
			for (int i = 0; i < DISP_SAMPLES - 1; i++) {
				float x0 = i       * w / (DISP_SAMPLES - 1f);
				float x1 = (i + 1) * w / (DISP_SAMPLES - 1f);
				float y0 = h / 2f - frame[i]     * h / 2f * 0.92f;
				float y1 = h / 2f - frame[i + 1] * h / 2f * 0.92f;
				mWavePaint.setColor(levelColor(Math.abs(frame[i])));
				canvas.drawLine(x0, y0, x1, y1, mWavePaint);
			}
			
			// Подпись
			canvas.drawText("OSC  T↑", 4, h - 3f, mLabelPaint);
		}
	}
	

	// ─── Огибающая: бегущий 10-секундный осциллограф ────────────────────────────
	// Хранит пиковые значения с шагом ~10 мс (CHUNK выборок).
	// Показывается когда осциллограф выключен; вертикальный масштаб совпадает.

	static class EnvelopeView extends View {
		private static final int HIST  = 1000; // 10 с × 100 точек/с
		private static final int CHUNK = 441;  // ~10 мс при 44100 Гц

		private final float[] mEnv    = new float[HIST];
		private int   mWritePos = 0;
		private int   mFilled   = 0;
		private float mAccPeak  = 0f;
		private int   mAccCount = 0;
		private final Object mLock = new Object();

		private final Paint mSegPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mGridPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mLabelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

		EnvelopeView(Context c) {
			super(c);
			setBackgroundColor(0x00000000);
			float d = c.getResources().getDisplayMetrics().density;
			mSegPaint.setStyle(Paint.Style.STROKE);
			mSegPaint.setStrokeWidth(1.6f * d);
			mSegPaint.setStrokeCap(Paint.Cap.ROUND);
			mGridPaint.setColor(0x33FFFFFF);
			mGridPaint.setStrokeWidth(0.8f);
			mGridPaint.setStyle(Paint.Style.STROKE);
			mLabelPaint.setColor(0xAAFFFFFF);
			mLabelPaint.setTextSize(9 * d);
			mLabelPaint.setAntiAlias(true);
		}

		void pushSamples(short[] buf, int len, int channels) {
			synchronized (mLock) {
				for (int i = 0; i < len; i += channels) {
					float s = Math.abs(buf[i] / 32768f);
					if (channels == 2 && i + 1 < len)
						s = Math.max(s, Math.abs(buf[i + 1] / 32768f));
					if (s > mAccPeak) mAccPeak = s;
					mAccCount++;
					if (mAccCount >= CHUNK) {
						mEnv[mWritePos] = mAccPeak;
						mWritePos = (mWritePos + 1) % HIST;
						if (mFilled < HIST) mFilled++;
						mAccPeak  = 0f;
						mAccCount = 0;
					}
				}
			}
			postInvalidate();
		}

		@Override
		protected void onDraw(Canvas canvas) {
			final float w = getWidth(), h = getHeight();
			if (w == 0 || h == 0) return;

			// Сетка (как у осциллографа)
			for (int gx = 1; gx < 4; gx++)
				canvas.drawLine(w * gx / 4f, 0, w * gx / 4f, h, mGridPaint);
			for (int gy = 1; gy < 4; gy++)
				canvas.drawLine(0, h * gy / 4f, w, h * gy / 4f, mGridPaint);
			Paint zeroPaint = new Paint(mGridPaint);
			zeroPaint.setColor(0x55FFFFFF);
			zeroPaint.setStrokeWidth(1.4f);
			canvas.drawLine(0, h / 2f, w, h / 2f, zeroPaint);

			float[] snap;
			int filled, writePos;
			synchronized (mLock) {
				snap     = mEnv.clone();
				filled   = mFilled;
				writePos = mWritePos;
			}
			if (filled < 2) {
				mLabelPaint.setColor(0xAAFFFFFF);
				canvas.drawText("ENV  10s", 4, h - 3f, mLabelPaint);
				return;
			}

			int count = Math.min(filled, HIST);
			int start = (filled < HIST) ? 0 : writePos;

			// Рисуем симметричную огибающую цветными сегментами
			for (int i = 0; i < count - 1; i++) {
				float a0 = snap[(start + i)     % HIST];
				float a1 = snap[(start + i + 1) % HIST];
				float x0 = i       * w / (count - 1f);
				float x1 = (i + 1) * w / (count - 1f);
				float yT0 = h / 2f - a0 * h / 2f * 0.92f;
				float yT1 = h / 2f - a1 * h / 2f * 0.92f;
				float yB0 = h / 2f + a0 * h / 2f * 0.92f;
				float yB1 = h / 2f + a1 * h / 2f * 0.92f;
				mSegPaint.setColor(OscilloscopeView.levelColor((a0 + a1) * 0.5f));
				canvas.drawLine(x0, yT0, x1, yT1, mSegPaint);
				canvas.drawLine(x0, yB0, x1, yB1, mSegPaint);
			}

			// Вертикальная черта «сейчас» (правый край)
			Paint curPaint = new Paint();
			curPaint.setColor(0x66FFFFFF);
			curPaint.setStrokeWidth(1f);
			canvas.drawLine(w - 1f, 0, w - 1f, h, curPaint);

			mLabelPaint.setColor(0xAAFFFFFF);
			canvas.drawText("ENV  10s", 4, h - 3f, mLabelPaint);
		}
	}

	// ─── Спектр-анализатор: FFT 2048 точек ───────────────────────────────────
	// Компактный вид в нижней панели. Логарифмическая шкала частот.
	// Накопительный буфер: когда накоплено >= FFT_SIZE выборок — считаем FFT.
	
	static class SpectrumView extends View {
		private static final int FFT_SIZE = 2048;
		private static final int HALF = FFT_SIZE / 2;
		
		private final float[] mAccBuf = new float[FFT_SIZE];
		private int mAccPos = 0;
		
		private final float[] mMagnitude = new float[HALF]; // последний спектр
		private final float[] mSmooth = new float[HALF];    // сглаженный
		private final float[] mPeaks = new float[HALF];     // пик-холд для спектра
		private final Object mLock = new Object();
		
		// FFT рабочие массивы (переиспользуются)
		private final float[] mFftRe = new float[FFT_SIZE];
		private final float[] mFftIm = new float[FFT_SIZE];
		// Окно Ханна
		private final float[] mWindow = new float[FFT_SIZE];
		
		private final Paint mBarPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mPeakPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mLblPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		private final Paint mBgPaint = new Paint();
		
		private static final int DISPLAY_BINS = 60; // уменьшено вдвое
		private static final float SAMPLE_RATE = 44100f;
		private static final float DECAY = 0.82f;    // коэффициент спада сглаженного
		private static final float PEAK_DECAY = 0.996f;
		
		SpectrumView(Context c) {
			super(c);
			// Окно Ханна
			for (int i = 0; i < FFT_SIZE; i++)
				mWindow[i] = 0.5f * (1f - (float) Math.cos(2.0 * Math.PI * i / (FFT_SIZE - 1)));
			mBarPaint.setStyle(Paint.Style.FILL);
			mPeakPaint.setStyle(Paint.Style.STROKE);
			mPeakPaint.setColor(0xFFFFFFFF);
			mPeakPaint.setStrokeWidth(1.5f);
			mLblPaint.setColor(0xCCFFFFFF);
			mLblPaint.setTextSize(7.5f * c.getResources().getDisplayMetrics().density);
			mLblPaint.setAntiAlias(true);
			mBgPaint.setColor(0x00000000); // полностью прозрачный фон
		}
		
		/** Получает новый блок PCM-16, микширует в моно, накапливает до FFT_SIZE */
		void pushSamples(short[] buf, int len, int channels) {
			for (int i = 0; i < len; i += channels) {
				float mono = buf[i] / 32768f;
				if (channels == 2 && i + 1 < len)
					mono = (mono + buf[i + 1] / 32768f) * 0.5f;
				mAccBuf[mAccPos++] = mono;
				if (mAccPos >= FFT_SIZE) {
					computeFFT();
					// Перекрытие 50% — сдвигаем буфер
					System.arraycopy(mAccBuf, FFT_SIZE / 2, mAccBuf, 0, FFT_SIZE / 2);
					mAccPos = FFT_SIZE / 2;
				}
			}
		}
		
		private void computeFFT() {
			// Применяем окно Ханна
			for (int i = 0; i < FFT_SIZE; i++) {
				mFftRe[i] = mAccBuf[i] * mWindow[i];
				mFftIm[i] = 0f;
			}
			// Cooley-Tukey in-place radix-2 DIT FFT
			int n = FFT_SIZE;
			for (int i = 1, j = 0; i < n; i++) {
				int bit = n >> 1;
				for (; (j & bit) != 0; bit >>= 1) j ^= bit;
				j ^= bit;
				if (i < j) {
					float tr = mFftRe[i]; mFftRe[i] = mFftRe[j]; mFftRe[j] = tr;
					float ti = mFftIm[i]; mFftIm[i] = mFftIm[j]; mFftIm[j] = ti;
				}
			}
			for (int len = 2; len <= n; len <<= 1) {
				double ang = -2.0 * Math.PI / len;
				float wRe = (float) Math.cos(ang), wIm = (float) Math.sin(ang);
				for (int i = 0; i < n; i += len) {
					float curRe = 1f, curIm = 0f;
					for (int k = 0; k < len / 2; k++) {
						float uRe = mFftRe[i + k], uIm = mFftIm[i + k];
						float vRe = mFftRe[i + k + len/2] * curRe - mFftIm[i + k + len/2] * curIm;
						float vIm = mFftRe[i + k + len/2] * curIm + mFftIm[i + k + len/2] * curRe;
						mFftRe[i + k]         = uRe + vRe;
						mFftIm[i + k]         = uIm + vIm;
						mFftRe[i + k + len/2] = uRe - vRe;
						mFftIm[i + k + len/2] = uIm - vIm;
						float nRe = curRe * wRe - curIm * wIm;
						curIm = curRe * wIm + curIm * wRe;
						curRe = nRe;
					}
				}
			}
			// Вычисляем амплитуду в дБ
			synchronized (mLock) {
				for (int i = 0; i < HALF; i++) {
					float mag = (float) Math.sqrt(mFftRe[i]*mFftRe[i] + mFftIm[i]*mFftIm[i]) / (FFT_SIZE / 2f);
					float db = mag > 1e-9f ? Math.max(-90f, (float)(20.0 * Math.log10(mag))) : -90f;
					// Нормализуем 0..1 (от -90dB до 0dB)
					float norm = (db + 90f) / 90f;
					mMagnitude[i] = norm;
					mSmooth[i] = Math.max(norm, mSmooth[i] * DECAY);
					mPeaks[i] = Math.max(mSmooth[i], mPeaks[i] * PEAK_DECAY);
				}
			}
			postInvalidate();
		}
		
		@Override
		protected void onDraw(Canvas canvas) {
			final float w = getWidth(), h = getHeight();
			if (w == 0 || h == 0) return;

			// Фон полностью прозрачный — не рисуем ничего
			// canvas.drawRect(0, 0, w, h, mBgPaint);

			final float lblH = mLblPaint.getTextSize() + 4f;
			final float barTop   = lblH;            // верхняя полоса зарезервирована под метки
			final float barAreaH = h - barTop;      // высота зоны баров

			float[] freqMarks  = {50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
			String[] freqLabels = {"50", "100", "200", "500", "1k", "2k", "5k", "10k", "20k"};
			float fMin = (float) Math.log10(20.0);
			float fMax = (float) Math.log10(SAMPLE_RATE / 2f);

			// Сетка только в зоне баров (ниже полосы меток)
			Paint gridPaint = new Paint();
			gridPaint.setColor(0x44FFFFFF);
			gridPaint.setStrokeWidth(0.8f);
			for (int fi = 0; fi < freqMarks.length; fi++) {
				if (freqMarks[fi] > SAMPLE_RATE / 2f) break;
				float xf = ((float) Math.log10(freqMarks[fi]) - fMin) / (fMax - fMin) * w;
				canvas.drawLine(xf, barTop, xf, h, gridPaint);
			}

			// Полосы спектра
			float[] smooth, peaks;
			synchronized (mLock) {
				smooth = mSmooth.clone();
				peaks  = mPeaks.clone();
			}

			float logFMin  = (float) Math.log10(Math.max(1f, 20f));
			float logFMaxV = (float) Math.log10(SAMPLE_RATE / 2f);

			for (int b = 0; b < DISPLAY_BINS; b++) {
				float logF0 = logFMin + (float) b       / DISPLAY_BINS * (logFMaxV - logFMin);
				float logF1 = logFMin + (float)(b + 1)  / DISPLAY_BINS * (logFMaxV - logFMin);
				float f0 = (float) Math.pow(10.0, logF0);
				float f1 = (float) Math.pow(10.0, logF1);

				int bin0 = Math.max(0,        Math.round(f0 / SAMPLE_RATE * FFT_SIZE));
				int bin1 = Math.min(HALF - 1, Math.round(f1 / SAMPLE_RATE * FFT_SIZE));

				float val = 0f, pk = 0f;
				for (int i = bin0; i <= bin1; i++) {
					if (smooth[i] > val) val = smooth[i];
					if (peaks[i]  > pk)  pk  = peaks[i];
				}

				float x0 = (float) b       / DISPLAY_BINS * w;
				float x1 = (float)(b + 1)  / DISPLAY_BINS * w - 1f;
				if (x1 < x0 + 0.5f) x1 = x0 + 0.5f;

				int red   = Math.min(255, (int)(val * 510f));
				int green = Math.min(255, (int)((1f - val) * 510f));
				mBarPaint.setColor(0xDD000000 | (red << 16) | (green << 8) | 0x22);
				float barH = val * barAreaH;
				canvas.drawRect(x0, h - barH, x1, h, mBarPaint);

				if (pk > 0.02f) {
					float peakY = h - pk * barAreaH;
					canvas.drawLine(x0, peakY, x1, peakY, mPeakPaint);
				}
			}

			// ── Метки частот в верхней полосе (всегда видны) ───────────────
			float labelY = lblH - 4f;
			float prevLblRight = -1f;
			mLblPaint.setTextAlign(Paint.Align.CENTER);
			for (int fi = 0; fi < freqMarks.length; fi++) {
				if (freqMarks[fi] > SAMPLE_RATE / 2f) break;
				float xf = ((float) Math.log10(freqMarks[fi]) - fMin) / (fMax - fMin) * w;
				float lblW = mLblPaint.measureText(freqLabels[fi]);
				float lblX = xf - lblW / 2f;
				if (lblX > prevLblRight && lblX + lblW < w - 2f) {
					canvas.drawText(freqLabels[fi], xf, labelY, mLblPaint);
					prevLblRight = lblX + lblW + 3f;
				}
			}
		}
	}

}
